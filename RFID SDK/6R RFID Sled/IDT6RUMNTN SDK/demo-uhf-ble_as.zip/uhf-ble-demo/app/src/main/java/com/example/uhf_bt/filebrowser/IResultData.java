package com.example.uhf_bt.filebrowser;

/**
 * Created by Administrator on 2018-3-13.
 */

public interface IResultData {
    public String getPath();
}
