//
//  MyRFID_ios.h
//  MyRFID_ios
//
//  Created by 张炳磊 on 2019/11/9.
//  Copyright © 2019 Nicholas.ABing. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MyRFID_ios.
FOUNDATION_EXPORT double MyRFID_iosVersionNumber;

//! Project version string for MyRFID_ios.
FOUNDATION_EXPORT const unsigned char MyRFID_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyRFID_ios/PublicHeader.h>


