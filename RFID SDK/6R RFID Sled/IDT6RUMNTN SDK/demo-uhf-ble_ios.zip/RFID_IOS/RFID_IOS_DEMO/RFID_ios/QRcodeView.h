//
//  QRcodeView.h
//  RFID_ios
//
//  Created by hjl on 2018/10/19.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRcodeView : UIView<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)UIButton *scanBtn;
@property (nonatomic,strong)UIButton *cleanBtn;

@property (nonatomic,copy)void (^scanBlock)(void);
@property (nonatomic,copy)void (^cleanBlock)(void);

@property (nonatomic,strong)UITableView *tableView;

@property (nonatomic,strong)NSMutableArray *dataSource;

@end
