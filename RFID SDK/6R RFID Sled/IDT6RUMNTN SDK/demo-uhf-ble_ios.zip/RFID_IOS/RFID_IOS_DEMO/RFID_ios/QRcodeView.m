//
//  QRcodeView.m
//  RFID_ios
//
//  Created by hjl on 2018/10/19.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import "QRcodeView.h"
#import <Masonry.h>
#import "QRcodeViewCell.h"

//iPhone_X layout

#define SCREEN_WIDTH              [UIScreen mainScreen].bounds.size.width

#define SCREEN_HEIGHT             [UIScreen mainScreen].bounds.size.height
#define iPhone_X                 (SCREEN_HEIGHT == 812.0)
#define Status_H                 (iPhone_X ? 44 : 20)
#define NavBar_H                  44
#define Nav_Height                (Status_H + NavBar_H)
#define Tab_Height                (iPhone_X ? 83 : 49)
#define ScaleW(value)             (value/375.0 * SCREEN_WIDTH)
#define iPhoneX_Bottom_Margin      20
#define Bottom_Margin              (iPhone_X ? -20 : 0)
#define BannerH                    ScaleW(186.0f)

@implementation QRcodeView

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        
        
        
        self.tableView=[[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        [self addSubview:self.tableView];
        
        self.tableView.delegate=self;
        self.tableView.dataSource=self;
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.equalTo(self);
            make.bottom.equalTo(self).offset(-50);
        }];
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.tableView.tableFooterView=[UIView new];
        [self.tableView registerClass:[QRcodeViewCell class] forCellReuseIdentifier:@"aaa"];
        
        CGFloat width=([UIScreen mainScreen].bounds.size.width-40)/2.0;
        self.scanBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.scanBtn];
        [self.scanBtn setTitle:@"Scan" forState:UIControlStateNormal];
        [self.scanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        self.scanBtn.backgroundColor=[UIColor colorWithRed:210/255.0 green:210/255.0 blue:210/255.0 alpha:210/255.0];
        [self.scanBtn addTarget:self action:@selector(scanbtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.scanBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(10);
            //make.bottom.equalTo(self).offset(-5);
            make.bottom.mas_equalTo(Bottom_Margin);
            make.height.mas_equalTo(40);
            make.width.mas_equalTo(width);
        }];

        self.cleanBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.cleanBtn];
        self.cleanBtn.backgroundColor=[UIColor colorWithRed:210/255.0 green:210/255.0 blue:210/255.0 alpha:210/255.0];
        [self.cleanBtn setTitle:@"Clear" forState:UIControlStateNormal];
        [self.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.cleanBtn addTarget:self action:@selector(clearbtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.cleanBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-10);
            //make.bottom.equalTo(self).offset(-5);
            make.bottom.mas_equalTo(Bottom_Margin);
            make.height.mas_equalTo(40);
            make.width.mas_equalTo(width);
        }];
        
    }
    return self;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
   
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    QRcodeViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"aaa" forIndexPath:indexPath];
    cell.titleLab.text=self.dataSource[indexPath.row];
    
    
    return cell;
}


-(void)scanbtnn
{
    if (self.scanBlock) {
        self.scanBlock();
    }
}
-(void)clearbtnn
{
    if (self.cleanBlock) {
        self.cleanBlock();
    }
}

@end
