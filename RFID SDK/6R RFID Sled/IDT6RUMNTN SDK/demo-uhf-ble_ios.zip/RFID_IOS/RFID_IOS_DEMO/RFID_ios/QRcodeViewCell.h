//
//  QRcodeViewCell.h
//  RFID_ios
//
//  Created by hjl on 2018/10/30.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRcodeViewCell : UITableViewCell

@property (nonatomic,strong)UILabel *titleLab;

@end
