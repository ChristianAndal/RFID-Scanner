//
//  ScanTwoView.h
//  RFID_ios
//
//  Created by chainway on 2019/6/17.
//  Copyright © 2019年 chainway. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ScanTwoView : UIView<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)UIButton *epcBtn;
@property (nonatomic,strong)UIButton *epcTidBtn;
@property (nonatomic,strong)UIButton *epcTidUserBtn;

@property (nonatomic,strong)NSString *chooseStr;

@property (nonatomic,strong)UITextField *userText;
@property (nonatomic,strong)UITextField *userLengthText;

@property (nonatomic,strong)UIButton *singleBtn;
@property (nonatomic,strong)UIButton *beginBtn;
@property (nonatomic,strong)UIButton *stopBtn;
@property (nonatomic,strong)UIButton *cleanBtn;


@property (nonatomic,copy)void (^epcBlock)(void);
@property (nonatomic,copy)void (^epcTidBlock)(void);
@property (nonatomic,copy)void (^epcTidUserBlock)(void);

@property (nonatomic,copy)void (^getttBlock)(void);
@property (nonatomic,copy)void (^setttBlock)(void);



@property (nonatomic,copy)void (^singleBlock)(void);
@property (nonatomic,copy)void (^beginBlock)(void);
@property (nonatomic,copy)void (^stopBlock)(void);
@property (nonatomic,copy)void (^cleanBlock)(void);

@property (nonatomic,strong)UILabel *tagLab;

@property (nonatomic,strong)UILabel *countLab;
@property (nonatomic,strong)UILabel *allCountLab;

@property (nonatomic,strong)UILabel *countLabTwo;


@property (nonatomic,strong)NSMutableArray *dataSource;

@property (nonatomic,strong)NSMutableArray *countArr;


@property (nonatomic,strong)NSMutableArray *dataSource1;

@property (nonatomic,strong)NSMutableArray *countArr1;

@property (nonatomic,strong)NSMutableArray *dataSource2;

@property (nonatomic,strong)NSMutableArray *countArr2;

@property (nonatomic,strong)UITableView *tableView;


-(void)chooseSelectWith:(NSString *)chooseStr;


@end

NS_ASSUME_NONNULL_END
