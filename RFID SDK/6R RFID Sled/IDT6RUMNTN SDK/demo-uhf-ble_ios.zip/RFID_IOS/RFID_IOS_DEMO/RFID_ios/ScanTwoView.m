//
//  ScanTwoView.m
//  RFID_ios
//
//  Created by chainway on 2019/6/17.
//  Copyright © 2019年 chainway. All rights reserved.
//

#import "ScanTwoView.h"

#import <Masonry.h>
#import "ScanViewCell.h"
#import "RFIDBlutoothManager.h"
#import "AppHelper.h"

#define RGB(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]
#define AdaptW(floatValue) floatValue
#define AdaptH(floatValue) floatValue

@implementation ScanTwoView

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        
        self.chooseStr = @"0";
        
        _epcBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_epcBtn];
        _epcBtn.backgroundColor=RGB(230, 230, 230, 1);
        _epcBtn.layer.masksToBounds=YES;
        _epcBtn.layer.cornerRadius=11;
        _epcBtn.layer.borderWidth=1;
        _epcBtn.selected = YES;
        _epcBtn.layer.borderColor=RGB(150, 150, 150, 1).CGColor;
        [_epcBtn addTarget:self action:@selector(epcBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_epcBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.top.equalTo(self).offset(20);
            make.width.mas_equalTo(22);
            make.height.mas_equalTo(22);
        }];
        UILabel *epcLab=[UILabel new];
        [self addSubview:epcLab];
        epcLab.font=[UIFont systemFontOfSize:15];
        epcLab.text=@"EPC";
        epcLab.textColor=[UIColor blackColor];
        [epcLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_epcBtn);
            make.height.mas_equalTo(25);
            make.left.equalTo(_epcBtn.mas_right).offset(10);
            make.width.mas_equalTo(50);
        }];
        
        _epcTidBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_epcTidBtn];
        _epcTidBtn.backgroundColor=[UIColor whiteColor];
        _epcTidBtn.layer.masksToBounds=YES;
        _epcTidBtn.layer.cornerRadius=11;
        _epcTidBtn.layer.borderWidth=1;
        _epcTidBtn.layer.borderColor=RGB(150, 150, 150, 1).CGColor;
        [_epcTidBtn addTarget:self action:@selector(epcTidBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_epcTidBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(epcLab.mas_right).offset(20);
            make.top.bottom.equalTo(_epcBtn);
            make.width.mas_equalTo(22);
            
        }];
        UILabel *epcTidLab=[UILabel new];
        [self addSubview:epcTidLab];
        epcTidLab.font=[UIFont systemFontOfSize:15];
        epcTidLab.text=@"EPC+TID";
        epcTidLab.textColor=[UIColor blackColor];
        [epcTidLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(epcLab);
            make.left.equalTo(_epcTidBtn.mas_right).offset(10);
            make.width.mas_equalTo(80);
        }];
        
        _epcTidUserBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_epcTidUserBtn];
        _epcTidUserBtn.backgroundColor=[UIColor whiteColor];
        _epcTidUserBtn.layer.masksToBounds=YES;
        _epcTidUserBtn.layer.cornerRadius=11;
        _epcTidUserBtn.layer.borderWidth=1;
        _epcTidUserBtn.layer.borderColor=RGB(150, 150, 150, 1).CGColor;
        [_epcTidUserBtn addTarget:self action:@selector(epcTidUserBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_epcTidUserBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(epcTidLab.mas_right).offset(20);
            make.top.bottom.equalTo(_epcBtn);
            make.width.mas_equalTo(22);
            
        }];
        UILabel *epcTidUserLab=[UILabel new];
        [self addSubview:epcTidUserLab];
        epcTidUserLab.font=[UIFont systemFontOfSize:15];
        epcTidUserLab.text=@"EPC+TID+USER";
        epcTidUserLab.textColor=[UIColor blackColor];
        [epcTidUserLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(epcLab);
            make.left.equalTo(_epcTidUserBtn.mas_right).offset(10);
            make.width.mas_equalTo(120);
        }];
     
        
        UILabel *userPtrLab=[UILabel new];
        [self addSubview:userPtrLab];
        userPtrLab.text=@"userPtr:";
        userPtrLab.font=[UIFont systemFontOfSize:14];
        userPtrLab.textColor=RGB(131, 131, 131, 1);
        [userPtrLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.top.equalTo(self.epcBtn.mas_bottom).offset(20);
            make.height.mas_equalTo(20);
            make.width.mas_equalTo(60);
        }];
        self.userText=[UITextField new];
        [self addSubview:self.userText];
        self.userText.keyboardType=UIKeyboardTypePhonePad;
        self.userText.font=[UIFont systemFontOfSize:16];
        self.userText.text = @"0";
        [self.userText mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(userPtrLab.mas_right).offset(5);
            make.top.bottom.equalTo(userPtrLab);
            make.width.mas_equalTo(100);
        }];
        UIView *linView=[UIView new];
        [self addSubview:linView];
        linView.backgroundColor=RGB(88, 88, 88, 1);
        [linView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(self.userText);
            make.top.equalTo(self.userText.mas_bottom);
            make.height.mas_equalTo(2);
        }];
        
        
        UILabel *userPtrlenLab=[UILabel new];
        [self addSubview:userPtrlenLab];
        userPtrlenLab.text=@"userLen:";
        userPtrlenLab.font=[UIFont systemFontOfSize:14];
        userPtrlenLab.textColor=RGB(131, 131, 131, 1);
        [userPtrlenLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_userText.mas_right).offset(15);
            make.top.bottom.equalTo(userPtrLab);
            make.width.mas_equalTo(60);
        }];
        self.userLengthText=[UITextField new];
        self.userLengthText.text = @"6";
        [self addSubview:self.userLengthText];
        self.userLengthText.keyboardType=UIKeyboardTypePhonePad;
        self.userLengthText.font=[UIFont systemFontOfSize:16];
        [self.userLengthText mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(userPtrlenLab.mas_right).offset(5);
            make.top.bottom.equalTo(userPtrLab);
            make.width.mas_equalTo(100);
        }];
        UIView *linView1=[UIView new];
        [self addSubview:linView1];
        linView1.backgroundColor=RGB(88, 88, 88, 1);
        [linView1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(self.userLengthText);
            make.top.equalTo(self.userLengthText.mas_bottom);
            make.height.mas_equalTo(2);
        }];
        
        self.singleBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.singleBtn];
        [self.singleBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.singleBtn setTitle:@"Single" forState:UIControlStateNormal];
        self.singleBtn.backgroundColor=RGB(210, 210, 210, 1);
        self.singleBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.singleBtn addTarget:self action:@selector(singleBtnn) forControlEvents:UIControlEventTouchUpInside];
        CGFloat width=([UIScreen mainScreen].bounds.size.width-15*5)/4.0;
        [self.singleBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.top.equalTo(linView1.mas_bottom).offset(55);
            make.height.mas_equalTo(AdaptH(35));
            make.width.mas_equalTo(width);
        }];
        
        self.beginBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.beginBtn];
        self.beginBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.beginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.beginBtn setTitle:@"Start" forState:UIControlStateNormal];
        self.beginBtn.backgroundColor=RGB(210, 210, 210, 1);
        [self.beginBtn addTarget:self action:@selector(beginBtnn) forControlEvents:UIControlEventTouchUpInside];
        
        [self.beginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.singleBtn.mas_right).offset(15);
            make.top.bottom.equalTo(self.singleBtn);
            make.width.mas_equalTo(width);
        }];
        
        self.stopBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.stopBtn];
        self.stopBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.stopBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.stopBtn setTitle:@"Stop" forState:UIControlStateNormal];
        self.stopBtn.backgroundColor=RGB(210, 210, 210, 1);
        [self.stopBtn addTarget:self action:@selector(stopBtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.stopBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(self.beginBtn);
            make.left.equalTo(self.beginBtn.mas_right).offset(15);
            make.width.mas_equalTo(width);
        }];
        
        self.cleanBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.cleanBtn];
        self.cleanBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.cleanBtn setTitle:@"Clear" forState:UIControlStateNormal];
        self.cleanBtn.backgroundColor=RGB(210, 210, 210, 1);
        [self.cleanBtn addTarget:self action:@selector(cleanBtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.cleanBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(self.beginBtn);
            make.right.equalTo(self).offset(-15);
            make.width.mas_equalTo(width);
        }];
        
        _tagLab=[UILabel new];
        [self addSubview:_tagLab];
        _tagLab.text=@"EPC";
        _tagLab.textColor=RGB(111, 111, 111, 1);
        _tagLab.font=[UIFont systemFontOfSize:16];
        [_tagLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.cleanBtn.mas_bottom).offset(10);
            make.left.equalTo(self).offset(5);
            make.width.mas_equalTo(99);
            make.height.mas_equalTo(25);
        }];
        self.countLab=[UILabel new];
        [self addSubview:self.countLab];
        self.countLab.text=@"0";
        self.countLab.font=[UIFont systemFontOfSize:16];
        self.countLab.textColor=RGB(111, 111, 111, 1);
        [self.countLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_tagLab);
            make.width.mas_equalTo(50);
            make.left.equalTo(self).offset(AdaptW(100));
        }];
        
        self.allCountLab=[UILabel new];
        [self addSubview:self.allCountLab];
        self.allCountLab.font=[UIFont systemFontOfSize:16];
        self.allCountLab.text=@"0";
        self.allCountLab.textColor=RGB(111, 111, 111, 1);
        [self.allCountLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_tagLab);
            make.width.mas_equalTo(50);
            make.left.equalTo(self).offset(AdaptW(160));
        }];
        
        _countLabTwo=[UILabel new];
        [self addSubview:_countLabTwo];
        _countLabTwo.textColor=RGB(111, 111, 111, 1);
        _countLabTwo.font=[UIFont systemFontOfSize:16];
        _countLabTwo.text=@"Count";
        [_countLabTwo mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_tagLab);
            make.width.mas_equalTo(70);
            make.right.equalTo(self).offset(-AdaptW(60));
        }];
        
        UILabel *rssiLab=[UILabel new];
        [self addSubview:rssiLab];
        rssiLab.textColor=RGB(111, 111, 111, 1);
        rssiLab.font=[UIFont systemFontOfSize:16];
        rssiLab.text=@"RSSI";
        [rssiLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_tagLab);
            make.width.mas_equalTo(40);
            make.right.equalTo(self).offset(-AdaptW(7));
        }];
        
        self.tableView=[[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        [self addSubview:self.tableView];
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.equalTo(self);
            make.top.equalTo(_tagLab.mas_bottom);
        }];
        self.tableView.delegate=self;
        self.tableView.dataSource=self;
        self.tableView.tableFooterView=[UIView new];
        [self.tableView registerClass:[ScanViewCell class] forCellReuseIdentifier:@"aaa"];
    }
    return self;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 85;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ScanViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"aaa" forIndexPath:indexPath];
    if ([[RFIDBlutoothManager shareManager].tagTypeStr isEqualToString:@"0"]) {
        //  EPC
        NSString *allDataStr = self.dataSource[indexPath.row];
        cell.epcLab.text = [allDataStr substringToIndex:allDataStr.length - 4];
        cell.countLab.text=[NSString stringWithFormat:@"%@",self.countArr[indexPath.row]];
        NSString *rssiStr = [allDataStr substringFromIndex:allDataStr.length - 4];
        NSInteger numOfRssiStr = [AppHelper getDecimalByBinary:[AppHelper getBinaryByHex:rssiStr]];
        CGFloat rssi = (65535 - numOfRssiStr) / 10.0;
        if (numOfRssiStr > 0) {
            cell.rssiLab.text = [NSString stringWithFormat:@"-%.2f",rssi];
        }
    }
    else if ([[RFIDBlutoothManager shareManager].tagTypeStr isEqualToString:@"1"])
    {
        //  EPC + TID
        NSString *tidAndRSSIStr = self.dataSource1[indexPath.row];
        NSString *tidStr = [tidAndRSSIStr substringToIndex:tidAndRSSIStr.length - 4];
        cell.epcLab.text=[NSString stringWithFormat:@"EPC:%@\nTID:%@",self.dataSource[indexPath.row],tidStr];
        cell.countLab.text = [NSString stringWithFormat:@"%@",self.countArr[indexPath.row]];
        NSString *rssiStr = [tidAndRSSIStr substringFromIndex:tidAndRSSIStr.length - 4];
        NSInteger numOfRssiStr = [AppHelper getDecimalByBinary:[AppHelper getBinaryByHex:rssiStr]];
        CGFloat rssi = (65535 - numOfRssiStr) / 10.0;
        if (numOfRssiStr > 0) {
            cell.rssiLab.text = [NSString stringWithFormat:@"-%.2f",rssi];
        }
    }
    else if ([[RFIDBlutoothManager shareManager].tagTypeStr isEqualToString:@"2"])
    {
        //  EPC + TID + USER
        if (indexPath.row < self.dataSource2.count) {
            NSString *userAndRssiStr = self.dataSource2[indexPath.row];
            NSString *userStr = [userAndRssiStr substringToIndex:userAndRssiStr.length - 4];
            cell.epcLab.text=[NSString stringWithFormat:@"EPC:%@\nTID:%@\nUSER:%@",self.dataSource[indexPath.row],self.dataSource1[indexPath.row],userStr];
            cell.countLab.text = [NSString stringWithFormat:@"%@",self.countArr[indexPath.row]];
            NSString *rssiStr = [userAndRssiStr substringFromIndex:userAndRssiStr.length - 4];
            NSInteger numOfRssiStr = [AppHelper getDecimalByBinary:[AppHelper getBinaryByHex:rssiStr]];
            CGFloat rssi = (65535 - numOfRssiStr) / 10.0;
            if (numOfRssiStr > 0) {
                cell.rssiLab.text = [NSString stringWithFormat:@"-%.2f",rssi];
            }
        }
    }
    
    return cell;
}

-(void)epcBtnn
{
    if (self.epcBlock) {
        self.epcBlock();
    }
    self.chooseStr = @"0";
    self.epcBtn.backgroundColor=RGB(230, 230, 230, 1);
    self.epcTidBtn.backgroundColor=[UIColor whiteColor];
    self.epcTidUserBtn.backgroundColor=[UIColor whiteColor];
    
}
-(void)epcTidBtnn
{
    if (self.epcTidBlock) {
        self.epcTidBlock();
    }
    self.chooseStr = @"1";
    self.epcBtn.backgroundColor=[UIColor whiteColor];
    self.epcTidBtn.backgroundColor=RGB(230, 230, 230, 1);
    self.epcTidUserBtn.backgroundColor=[UIColor whiteColor];
}
-(void)epcTidUserBtnn
{
    
    if (self.epcTidUserBlock) {
        self.epcTidUserBlock();
    }
    
    self.chooseStr = @"2";
    
    self.epcBtn.backgroundColor=[UIColor whiteColor];
    self.epcTidBtn.backgroundColor=[UIColor whiteColor];
    self.epcTidUserBtn.backgroundColor=RGB(230, 230, 230, 1);
}

-(void)singleBtnn
{
    if (self.singleBlock) {
        self.singleBlock();
    }
    
}
-(void)beginBtnn
{
    if (self.beginBlock) {
        self.beginBlock();
    }
    [self.beginBtn setTitleColor:RGB(133, 133, 133, 1) forState:UIControlStateNormal];
    [self.stopBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}
-(void)stopBtnn
{
    if (self.stopBlock) {
        self.stopBlock();
    }
    [self.beginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.stopBtn setTitleColor:RGB(133, 133, 133, 1) forState:UIControlStateNormal];
    [self.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}
-(void)cleanBtnn
{
    if (self.cleanBlock) {
        self.cleanBlock();
    }
    [self.beginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.stopBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.cleanBtn setTitleColor:RGB(133, 133, 133, 1) forState:UIControlStateNormal];
}


-(void)chooseSelectWith:(NSString *)chooseStr
{
    if (chooseStr.integerValue ==0) {
        self.epcBtn.backgroundColor=RGB(230, 230, 230, 1);
        self.epcTidBtn.backgroundColor=[UIColor whiteColor];
        self.epcTidUserBtn.backgroundColor=[UIColor whiteColor];
    }
    else if (chooseStr.integerValue ==1)
    {
        self.epcBtn.backgroundColor=[UIColor whiteColor];
        self.epcTidBtn.backgroundColor=RGB(230, 230, 230, 1);
        self.epcTidUserBtn.backgroundColor=[UIColor whiteColor];
    }
    else if (chooseStr.integerValue ==2)
    {
        self.epcBtn.backgroundColor=[UIColor whiteColor];
        self.epcTidBtn.backgroundColor=[UIColor whiteColor];
        self.epcTidUserBtn.backgroundColor=RGB(230, 230, 230, 1);
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
