//
//  ScanView.h
//  RFID_ios
//
//  Created by chainway on 2018/4/26.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanView : UIView<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)UIButton *singleBtn;
@property (nonatomic,strong)UIButton *beginBtn;
@property (nonatomic,strong)UIButton *stopBtn;
@property (nonatomic,strong)UIButton *cleanBtn;

@property (nonatomic,copy)void (^singleBlock)(void);
@property (nonatomic,copy)void (^beginBlock)(void);
@property (nonatomic,copy)void (^stopBlock)(void);
@property (nonatomic,copy)void (^cleanBlock)(void);

@property (nonatomic,strong)UILabel *tagLab;

@property (nonatomic,strong)UILabel *countLab;
@property (nonatomic,strong)UILabel *allCountLab;

@property (nonatomic,strong)UILabel *countLabTwo;


@property (nonatomic,strong)NSMutableArray *dataSource;

@property (nonatomic,strong)NSMutableArray *countArr;


@property (nonatomic,strong)UITableView *tableView;

@end
