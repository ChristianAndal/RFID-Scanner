//
//  ScanView.m
//  RFID_ios
//
//  Created by chainway on 2018/4/26.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import "ScanView.h"
#import <Masonry.h>
#import "ScanViewCell.h"

#define RGB(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]
#define AdaptW(floatValue) floatValue
#define AdaptH(floatValue) floatValue
@implementation ScanView

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        
        self.singleBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.singleBtn];
        self.singleBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.singleBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.singleBtn setTitle:@"Single" forState:UIControlStateNormal];
        self.singleBtn.backgroundColor=RGB(210, 210, 210, 1);
        
        [self.singleBtn addTarget:self action:@selector(singleBtnn) forControlEvents:UIControlEventTouchUpInside];
        CGFloat width=([UIScreen mainScreen].bounds.size.width-15*5)/4.0;
        [self.singleBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(self).offset(15);
            make.height.mas_equalTo(AdaptH(40));
            make.width.mas_equalTo(width);
        }];
        
        self.beginBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.beginBtn];
        self.beginBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.beginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.beginBtn setTitle:@"Start" forState:UIControlStateNormal];
        self.beginBtn.backgroundColor=RGB(210, 210, 210, 1);
        [self.beginBtn addTarget:self action:@selector(beginBtnn) forControlEvents:UIControlEventTouchUpInside];
     
        [self.beginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.singleBtn.mas_right).offset(15);
            make.top.bottom.equalTo(self.singleBtn);
            make.width.mas_equalTo(width);
        }];
        
        self.stopBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.stopBtn];
        self.stopBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.stopBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.stopBtn setTitle:@"Stop" forState:UIControlStateNormal];
        self.stopBtn.backgroundColor=RGB(210, 210, 210, 1);
        [self.stopBtn addTarget:self action:@selector(stopBtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.stopBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(self.beginBtn);
            make.left.equalTo(self.beginBtn.mas_right).offset(15);
            make.width.mas_equalTo(width);
        }];
        
        self.cleanBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.cleanBtn];
        self.cleanBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.cleanBtn setTitle:@"Clear" forState:UIControlStateNormal];
        self.cleanBtn.backgroundColor=RGB(210, 210, 210, 1);
        [self.cleanBtn addTarget:self action:@selector(cleanBtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.cleanBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(self.beginBtn);
            make.right.equalTo(self).offset(-15);
            make.width.mas_equalTo(width);
        }];
        
        
        
        _tagLab=[UILabel new];
        [self addSubview:_tagLab];
        _tagLab.text=@"EPC";
        _tagLab.textColor=RGB(111, 111, 111, 1);
        _tagLab.font=[UIFont systemFontOfSize:16];
        [_tagLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.cleanBtn.mas_bottom).offset(10);
            make.left.equalTo(self).offset(5);
            make.width.mas_equalTo(99);
            make.height.mas_equalTo(25);
        }];
        self.countLab=[UILabel new];
        [self addSubview:self.countLab];
        self.countLab.text=@"0";
        self.countLab.font=[UIFont systemFontOfSize:16];
        self.countLab.textColor=RGB(111, 111, 111, 1);
        [self.countLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_tagLab);
            make.width.mas_equalTo(50);
            make.left.equalTo(self).offset(AdaptW(100));
        }];
        
        self.allCountLab=[UILabel new];
        [self addSubview:self.allCountLab];
        self.allCountLab.font=[UIFont systemFontOfSize:16];
        self.allCountLab.text=@"0";
        self.allCountLab.textColor=RGB(111, 111, 111, 1);
        [self.allCountLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_tagLab);
            make.width.mas_equalTo(50);
            make.left.equalTo(self).offset(AdaptW(160));
        }];
        
        _countLabTwo=[UILabel new];
        [self addSubview:_countLabTwo];
        _countLabTwo.textColor=RGB(111, 111, 111, 1);
        _countLabTwo.font=[UIFont systemFontOfSize:16];
        _countLabTwo.text=@"Count";
        [_countLabTwo mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_tagLab);
            make.width.mas_equalTo(70);
            make.right.equalTo(self).offset(-AdaptW(60));
        }];
        
        UILabel *rssiLab=[UILabel new];
        [self addSubview:rssiLab];
        rssiLab.textColor=RGB(111, 111, 111, 1);
        rssiLab.font=[UIFont systemFontOfSize:16];
        rssiLab.text=@"RSSI";
        [rssiLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_tagLab);
            make.width.mas_equalTo(40);
            make.right.equalTo(self).offset(-AdaptW(7));
        }];
        
        self.tableView=[[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        [self addSubview:self.tableView];
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.equalTo(self);
            make.top.equalTo(_tagLab.mas_bottom);
        }];
        self.tableView.delegate=self;
        self.tableView.dataSource=self;
        self.tableView.tableFooterView=[UIView new];
        [self.tableView registerClass:[ScanViewCell class] forCellReuseIdentifier:@"aaa"];
        
        
        
        
    }
    return self;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ScanViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"aaa" forIndexPath:indexPath];
    cell.epcLab.text=self.dataSource[indexPath.row];
    cell.countLab.text=[NSString stringWithFormat:@"%@",self.countArr[indexPath.row]];
    return cell;
}
-(void)singleBtnn
{
    if (self.singleBlock) {
        self.singleBlock();
    }
 
}
-(void)beginBtnn
{
    if (self.beginBlock) {
        self.beginBlock();
    }
    [self.beginBtn setTitleColor:RGB(133, 133, 133, 1) forState:UIControlStateNormal];
    [self.stopBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}
-(void)stopBtnn
{
    if (self.stopBlock) {
        self.stopBlock();
    }
    [self.beginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.stopBtn setTitleColor:RGB(133, 133, 133, 1) forState:UIControlStateNormal];
    [self.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}
-(void)cleanBtnn
{
    if (self.cleanBlock) {
        self.cleanBlock();
    }
    [self.beginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.stopBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.cleanBtn setTitleColor:RGB(133, 133, 133, 1) forState:UIControlStateNormal];
}
@end
