//
//  SettingView.h
//  RFID_ios
//
//  Created by chainway on 2018/4/26.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingView : UIView

@property (nonatomic,strong)UILabel *workLab;
@property (nonatomic,strong)UIButton *setpinBtn;
@property (nonatomic,strong)UIButton *readpinBtn;
@property (nonatomic,strong)UILabel *usaLab;
@property (nonatomic,strong)UILabel *brazilLab;
@property (nonatomic,strong)UILabel *otherLab;

@property (nonatomic,strong)UIButton *setdianBtn;

@property (nonatomic,strong)UILabel *putLab;
@property (nonatomic,strong)UIButton *setgongBtn;
@property (nonatomic,strong)UIButton *readgongBtn;


@property (nonatomic,strong)UIButton *workBtn;
@property (nonatomic,strong)UIButton *hopBtn;
@property (nonatomic,strong)UIButton *putBtn;

@property (nonatomic,strong)UIButton *usaBtn;
@property (nonatomic,strong)UIButton *brazilBtn;
@property (nonatomic,strong)UIButton *otherBtn;

@property (nonatomic,strong)UIButton *buzzerOpen;
@property (nonatomic,strong)UIButton *buzzerClose;


@property (nonatomic,copy)void (^workBlock)(void);
@property (nonatomic,copy)void (^hopBlock)(void);
@property (nonatomic,copy)void (^putBlock)(void);

@property (nonatomic,copy)void (^usaBlock)(void);
@property (nonatomic,copy)void (^brazilBlock)(void);
@property (nonatomic,copy)void (^otherBlock)(void);

@property (nonatomic,copy)void (^buzzerOpenBlock)(void);
@property (nonatomic,copy)void (^buzzerCloseBlock)(void);


@property (nonatomic,copy)void (^setpinBlock)(void);
@property (nonatomic,copy)void (^readpinBlock)(void);
@property (nonatomic,copy)void (^setdianBlock)(void);
@property (nonatomic,copy)void (^setgongBlock)(void);
@property (nonatomic,copy)void (^readgongBlock)(void);



@end
