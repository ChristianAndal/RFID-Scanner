//
//  SettingView.m
//  RFID_ios
//
//  Created by chainway on 2018/4/26.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import "SettingView.h"
#import <Masonry.h>
#define RGB(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]
#define AdaptW(floatValue) floatValue
#define AdaptH(floatValue) floatValue
@implementation SettingView

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        
        
        _workLab=[UILabel new];
        [self addSubview:_workLab];
        _workLab.text=@"Working Mode:";
        _workLab.font=[UIFont systemFontOfSize:15];
        _workLab.textColor=RGB(150, 150, 150, 1);
        [_workLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(self).offset(15);
            make.height.mas_equalTo(AdaptH(25));
            make.width.mas_equalTo(120);
        }];
        
        self.workBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.workBtn];
        [self.workBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.workBtn setTitle:@"欧洲标准(865~868MHZ)" forState:UIControlStateNormal];
        self.workBtn.titleLabel.font=[UIFont systemFontOfSize:15];
        self.workBtn.titleLabel.textAlignment=NSTextAlignmentLeft;
        [self.workBtn addTarget:self action:@selector(workBtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.workBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_workLab);
            make.height.mas_equalTo(AdaptH(40));
            make.left.equalTo(_workLab.mas_right);
            make.right.equalTo(self);
        }];
        
        _setpinBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_setpinBtn];
        [_setpinBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_setpinBtn setTitle:@"FrequencySet" forState:UIControlStateNormal];
        _setpinBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        _setpinBtn.backgroundColor=RGB(210, 210, 210, 1);
        [_setpinBtn addTarget:self action:@selector(setpinBtnn) forControlEvents:UIControlEventTouchUpInside];
        CGFloat width=([UIScreen mainScreen].bounds.size.width-30-40)/2.0;
        [_setpinBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.top.equalTo(_workLab.mas_bottom).offset(20);
            make.height.mas_equalTo(AdaptH(40));
            make.width.mas_equalTo(width);
        }];
        
        _readpinBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_readpinBtn];
        [_readpinBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_readpinBtn setTitle:@"Read Frequency" forState:UIControlStateNormal];
        _readpinBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        _readpinBtn.backgroundColor=RGB(210, 210, 210, 1);
        [_readpinBtn addTarget:self action:@selector(readpinBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_readpinBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_setpinBtn);
            make.right.equalTo(self).offset(-15);
            make.width.mas_equalTo(width);
        }];
        
        
        _usaBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_usaBtn];
        _usaBtn.backgroundColor=RGB(230, 230, 230, 1);
        _usaBtn.layer.masksToBounds=YES;
        _usaBtn.layer.cornerRadius=11;
        _usaBtn.layer.borderWidth=1;
        _usaBtn.layer.borderColor=RGB(150, 150, 150, 1).CGColor;
        [_usaBtn addTarget:self action:@selector(usaBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_usaBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(20);
            make.top.equalTo(_readpinBtn.mas_bottom).offset(20);
            make.width.mas_equalTo(22);
            make.height.mas_equalTo(22);
        }];
        _usaLab=[UILabel new];
        [self addSubview:_usaLab];
        _usaLab.font=[UIFont systemFontOfSize:15];
        _usaLab.text=@"US";
        _usaLab.textColor=[UIColor blackColor];
        [_usaLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_usaBtn);
            make.height.mas_equalTo(25);
            make.left.equalTo(_usaBtn.mas_right).offset(10);
            make.width.mas_equalTo(50);
        }];

        _brazilBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_brazilBtn];
        _brazilBtn.backgroundColor=[UIColor whiteColor];
        _brazilBtn.layer.masksToBounds=YES;
        _brazilBtn.layer.cornerRadius=11;
        _brazilBtn.layer.borderWidth=1;
        _brazilBtn.layer.borderColor=RGB(150, 150, 150, 1).CGColor;
        [_brazilBtn addTarget:self action:@selector(brazilBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_brazilBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_usaLab.mas_right).offset(30);
            make.top.bottom.equalTo(_usaBtn);
            make.width.mas_equalTo(22);

        }];
        _brazilLab=[UILabel new];
        [self addSubview:_brazilLab];
        _brazilLab.font=[UIFont systemFontOfSize:15];
        _brazilLab.text=@"BRA";
        _brazilLab.textColor=[UIColor blackColor];
        [_brazilLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_usaLab);
            make.left.equalTo(_brazilBtn.mas_right).offset(10);
            make.width.mas_equalTo(50);
        }];

        _otherBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_otherBtn];
        _otherBtn.backgroundColor=[UIColor whiteColor];
        _otherBtn.layer.masksToBounds=YES;
        _otherBtn.layer.cornerRadius=11;
        _otherBtn.layer.borderWidth=1;
        _otherBtn.layer.borderColor=RGB(150, 150, 150, 1).CGColor;
        [_otherBtn addTarget:self action:@selector(otherBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_otherBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_brazilLab.mas_right).offset(30);
            make.top.bottom.equalTo(_usaBtn);
            make.width.mas_equalTo(22);

        }];
        _otherLab=[UILabel new];
        [self addSubview:_otherLab];
        _otherLab.font=[UIFont systemFontOfSize:15];
        _otherLab.text=@"Other";
        _otherLab.textColor=[UIColor blackColor];
        [_otherLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_usaLab);
            make.left.equalTo(_otherBtn.mas_right).offset(10);
            make.width.mas_equalTo(50);
        }];

        UILabel *hopLab=[UILabel new];
        [self addSubview:hopLab];
        hopLab.text=@"Hop:";
        hopLab.font=[UIFont systemFontOfSize:16];
        hopLab.textColor=RGB(150, 150, 150, 1);
        [hopLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.top.equalTo(_otherBtn.mas_bottom).offset(20);
            make.height.mas_equalTo(AdaptH(30));
            make.width.mas_equalTo(52);
        }];
        self.hopBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.hopBtn];
        [self.hopBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.hopBtn setTitle:@"902.12" forState:UIControlStateNormal];
        self.hopBtn.titleLabel.textAlignment=NSTextAlignmentLeft;
        self.hopBtn.titleLabel.font=[UIFont systemFontOfSize:16];
        [self.hopBtn addTarget:self action:@selector(hopBtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.hopBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(hopLab);
            make.height.mas_equalTo(AdaptH(40));
            make.left.equalTo(hopLab.mas_right);
            make.right.equalTo(self);
        }];
        _setdianBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_setdianBtn];
        [_setdianBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_setdianBtn setTitle:@"Set FreHop" forState:UIControlStateNormal];
        _setdianBtn.titleLabel.font =[UIFont systemFontOfSize:16];
        _setdianBtn.backgroundColor=RGB(210, 210, 210, 1);
        [_setdianBtn addTarget:self action:@selector(setdianBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_setdianBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.right.equalTo(self).offset(-15);
            make.height.mas_equalTo(AdaptH(40));
            make.top.equalTo(hopLab.mas_bottom).offset(10);
        }];


        _putLab=[UILabel new];
        [self addSubview:_putLab];
        _putLab.text=@"Output Power:";
        _putLab.font=[UIFont systemFontOfSize:15];
        _putLab.textColor=RGB(150, 150, 150, 1);
        [_putLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.top.equalTo(_setdianBtn.mas_bottom).offset(15);
            make.height.mas_equalTo(AdaptH(30));
            make.width.mas_equalTo(125);
        }];
        self.putBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.putBtn];
        [self.putBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.putBtn setTitle:@"10" forState:UIControlStateNormal];
        self.putBtn.titleLabel.font=[UIFont systemFontOfSize:16];
        [self.putBtn addTarget:self action:@selector(putBtnn) forControlEvents:UIControlEventTouchUpInside];
        [self.putBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_putLab);
            make.height.mas_equalTo(AdaptH(40));
            make.left.equalTo(_putLab.mas_right);
            make.right.equalTo(self).offset(-60);
        }];
        
        UILabel *label1=[UILabel new];
        label1.text = @"dBm";
        label1.font=[UIFont systemFontOfSize:16];
        [self addSubview:label1];
        [label1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.putBtn.mas_right);
            make.top.bottom.equalTo(self.putBtn);
            make.width.mas_equalTo(50);
        }];
        
        _setgongBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_setgongBtn];
        [_setgongBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_setgongBtn setTitle:@"PowerSet" forState:UIControlStateNormal];
        _setgongBtn.backgroundColor=RGB(210, 210, 210, 1);
        _setgongBtn.titleLabel.font =[UIFont systemFontOfSize:16];
        [_setgongBtn addTarget:self action:@selector(setgongBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_setgongBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.height.mas_equalTo(AdaptH(40));
            make.top.equalTo(_putLab.mas_bottom).offset(15);
            make.width.mas_equalTo(width);
        }];

        _readgongBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_readgongBtn];
        [_readgongBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_readgongBtn setTitle:@"Read power" forState:UIControlStateNormal];
        _readgongBtn.titleLabel.font =[UIFont systemFontOfSize:16];
        _readgongBtn.backgroundColor=RGB(210, 210, 210, 1);
        [_readgongBtn addTarget:self action:@selector(readgongBtnn) forControlEvents:UIControlEventTouchUpInside];
        [_readgongBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_setgongBtn);
            make.right.equalTo(self).offset(-15);
            make.width.mas_equalTo(width);
        }];
        
        
        UILabel *buzzerlabel=[UILabel new];
        [self addSubview:buzzerlabel];
        buzzerlabel.text = @"Buzzer";
        buzzerlabel.font=[UIFont systemFontOfSize:15];
        buzzerlabel.textColor=RGB(150, 150, 150, 1);
        [buzzerlabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.top.equalTo(_setgongBtn.mas_bottom).offset(15);
            make.height.mas_equalTo(AdaptH(30));
            make.width.mas_equalTo(125);
        }];
        
        _buzzerOpen=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_buzzerOpen];
        [_buzzerOpen setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_buzzerOpen setTitle:@"Buzzer open" forState:UIControlStateNormal];
        _buzzerOpen.backgroundColor=RGB(210, 210, 210, 1);
        _buzzerOpen.titleLabel.font =[UIFont systemFontOfSize:16];
        [_buzzerOpen addTarget:self action:@selector(buzzerOpenn) forControlEvents:UIControlEventTouchUpInside];
        [_buzzerOpen mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.height.mas_equalTo(AdaptH(40));
            make.top.equalTo(buzzerlabel.mas_bottom).offset(15);
            make.width.mas_equalTo(width);
        }];
        
        _buzzerClose=[UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_buzzerClose];
        [_buzzerClose setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_buzzerClose setTitle:@"Buzzer close" forState:UIControlStateNormal];
        _buzzerClose.titleLabel.font =[UIFont systemFontOfSize:16];
        _buzzerClose.backgroundColor=RGB(210, 210, 210, 1);
        [_buzzerClose addTarget:self action:@selector(buzzerClosee) forControlEvents:UIControlEventTouchUpInside];
        [_buzzerClose mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(_buzzerOpen);
            make.right.equalTo(self).offset(-15);
            make.width.mas_equalTo(width);
        }];
        
        
        
    }
    return self;
}
-(void)buzzerOpenn
{
    if (self.buzzerOpenBlock) {
        self.buzzerOpenBlock();
    }
}

-(void)buzzerClosee
{
    if (self.buzzerCloseBlock) {
        self.buzzerCloseBlock();
    }
}

-(void)workBtnn
{
    if (self.workBlock) {
        self.workBlock();
    }
}
-(void)setpinBtnn
{
    if (self.setpinBlock) {
        self.setpinBlock();
    }
}
-(void)readpinBtnn
{
    if (self.readpinBlock) {
        self.readpinBlock();
    }
}
-(void)usaBtnn
{
    self.usaBtn.backgroundColor=RGB(230, 230, 230, 1);
    self.brazilBtn.backgroundColor=[UIColor whiteColor];
    self.otherBtn.backgroundColor=[UIColor whiteColor];
    if (self.usaBlock) {
        self.usaBlock();
    }
    
}
-(void)brazilBtnn
{
    self.brazilBtn.backgroundColor=RGB(230, 230, 230, 1);
    self.usaBtn.backgroundColor=[UIColor whiteColor];
    self.otherBtn.backgroundColor=[UIColor whiteColor];
    if (self.brazilBlock) {
        self.brazilBlock();
    }
}
-(void)otherBtnn
{
    self.otherBtn.backgroundColor=RGB(230, 230, 230, 1);
    self.brazilBtn.backgroundColor=[UIColor whiteColor];
    self.usaBtn.backgroundColor=[UIColor whiteColor];
    if (self.otherBlock) {
        self.otherBlock();
    }
}
-(void)hopBtnn
{
    if (self.hopBlock) {
        self.hopBlock();
    }
}
-(void)setdianBtnn
{
    if (self.setdianBlock) {
        self.setdianBlock();
    }
}
-(void)putBtnn
{
    if (self.putBlock) {
        self.putBlock();
    }
}
-(void)setgongBtnn
{
    if (self.setgongBlock) {
        self.setgongBlock();
    }
}
-(void)readgongBtnn
{
    if (self.readgongBlock) {
        self.readgongBlock();
    }
}
@end
