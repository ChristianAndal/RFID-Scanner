//
//  ShadeCell.h
//  RFID_ios
//
//  Created by chainway on 2018/4/26.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShadeCell : UITableViewCell
@property (nonatomic,strong)UILabel *nameLab;
@property (nonatomic,strong)UILabel *identyLab;
@property (nonatomic,strong)UILabel *rssiLab;
@end
