//
//  ViewController.m
//  RFID_ios
//
//  Created by chainway on 2018/4/26.
//  Copyright © 2018年 chainway. All rights reserved.
//

#import "ViewController.h"
#import "BSprogreUtil.h"
#import "RFIDBlutoothManager.h"
#import "Masonry.h"
#import "AppDelegate.h"
#import "BLEModel.h"
#import "CustomNaviAlertView.h"
#import <IQKeyboardManager.h>
#import "TopView.h"
#import "ScanView.h"
#import "ScanTwoView.h"
#import "SettingView.h"
#import "EncryptionView.h"
#import "USERView.h"
#import "ReadMessageView.h"
#import "WriteMessageView.h"
#import "LockView.h"
#import "LockChooseeView.h"

#import "DestroyView.h"
#import "UpgradeView.h"

#import "ChooseView.h"
#import "QRcodeView.h"

#import "InternationalControl.h"




#define AdaptW(floatValue) floatValue
#define AdaptH(floatValue) floatValue
#define weakSelf(self) __weak typeof(self)weakSelf = self
#define kDefine 5
#define RGB(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]

@interface ViewController ()<PeripheralAddDelegate,FatScaleBluetoothManager,UIScrollViewDelegate>

@property (nonatomic,strong)TopView *topView;
@property (nonatomic,strong)UIScrollView *middleScrollView;

@property (nonatomic,strong)ScanView *scanView;
@property (nonatomic,strong)ScanTwoView *scanTwoView;
@property (nonatomic,strong)QRcodeView *codeView;
@property (nonatomic,strong)SettingView *settingview;
@property (nonatomic,strong)EncryptionView *encryView;
@property (nonatomic,strong)USERView *userrView;
@property (nonatomic,strong)ReadMessageView *readView;
@property (nonatomic,strong)WriteMessageView *writeView;
@property (nonatomic,strong)LockView *lockView;
@property (nonatomic,strong)LockChooseeView *lockchooseVieww;

@property (nonatomic,strong)DestroyView *destoryView;
@property (nonatomic,strong)UpgradeView *upgradeView;

@property (nonatomic ,strong)CustomNaviAlertView *searchAlert;

@property (nonatomic,strong)ChooseView *chooseView;


@property (nonatomic,strong)UIView *linView;

@property (nonatomic,strong)NSMutableArray *dataLinView;
@property (nonatomic,strong)NSMutableArray *dataBottomView;

@property (nonatomic,strong)NSMutableArray *modelArr;  //设置
@property (nonatomic,strong)NSMutableArray *hopArr;  //设置
@property (nonatomic,strong)NSMutableArray *putArr;   //设置

@property (nonatomic,strong)NSMutableArray *encryModelArr;   //加密
@property (nonatomic,strong)NSMutableArray *saveReadArr;   //读数据
@property (nonatomic,strong)NSMutableArray *saveWriteArr;   //写数据

@property (nonatomic,strong)NSMutableArray *updateArr;   //写数据

@property (nonatomic,strong)NSMutableArray *rcodeArr;   //扫描到的二维码数据


@property (nonatomic,assign)NSInteger modelIndex;
@property (nonatomic,assign)NSInteger hopIndex;
@property (nonatomic,assign)NSInteger putIndex;

@property (nonatomic,assign)NSInteger updateIndex;//写数据的计算

@property (nonatomic,assign)NSInteger encryModelIndex;
@property (nonatomic,assign)NSInteger saveReadIndex;
@property (nonatomic,assign)NSInteger saveWriteIndex;



@property (nonatomic,assign)NSInteger chooseIndex;



@property (nonatomic,assign)BOOL isConnect;

@end

@implementation ViewController


- (CustomNaviAlertView *)searchAlert{
    if (_searchAlert == nil) {
        _searchAlert = [[CustomNaviAlertView alloc]initWithFrame:CGRectMake(kDefine, ([UIScreen mainScreen].bounds.size.height-64)/4-80, [UIScreen mainScreen].bounds.size.width-kDefine*2, ([UIScreen mainScreen].bounds.size.height-64)/2)];
        _searchAlert = [[CustomNaviAlertView alloc]initWithFrame:CGRectMake(15, AdaptH(160), [UIScreen mainScreen].bounds.size.width-30, AdaptH(380))];
        _searchAlert = [[CustomNaviAlertView alloc]initWithFrame:self.view.bounds];
        weakSelf(self);
        
        _searchAlert.cancelBlock = ^()
        {
            [[RFIDBlutoothManager shareManager] startBleScan];
            [weakSelf.searchAlert.dataSource removeAllObjects];
            [weakSelf.searchAlert.myTableView reloadData];

            
            
        };
        _searchAlert.removeBlock=^()
        {
            [weakSelf.searchAlert removeFromSuperview];
            weakSelf.searchAlert=nil;
            [[RFIDBlutoothManager shareManager] closeBleAndDisconnect];
            
        };
        
    }
    return _searchAlert;
}


-(void)getUpdateData
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"Reader_v2_0_4" ofType:@"bin"];
    NSData *reader = [NSData dataWithContentsOfFile:path];
    
    
    
    NSString *dataStr=[BluetoothUtil stringWithHexBytes2:reader];
    NSLog(@"dataStr=======%@",dataStr);
    NSLog(@"dataStr.length===%lu",(unsigned long)dataStr.length);
    
    _updateArr=[[NSMutableArray alloc]init];
    
    NSString *str;
    for (NSInteger i=0; i<dataStr.length; i++) {
        
        str=[NSString stringWithFormat:@"%@%@",str,[dataStr substringWithRange:NSMakeRange(i,1)]];
        if (str.length==128) {
            [_updateArr addObject:str];
            str=@"";
        }
        if (i==dataStr.length-1) {
            NSLog(@"str.length====%lu",(unsigned long)str.length);//46  82
            NSInteger countt = str.length;
            for (NSInteger j=0; j<128-countt; j++) {
                str=[NSString stringWithFormat:@"%@%@",str,@"0"];
                
            }
            [_updateArr addObject:str];
        }
        
        
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    Byte rssi[2];
    rssi[0]=0xFD;
    rssi[1]=0x6F;
    int irssi = (rssi[0] & 0xFF) | (rssi[1] & 0x8000);
    float dBm = (65535 - irssi) / 10.0;
    NSLog(@"dBm=====%lf",dBm);
    
    
    self.dataBottomView=[[NSMutableArray alloc]init];
    self.isConnect=NO;
    
    [self initModelArr];
    [self initHopArr];
    [self initPutArr];
    [self initencryModelArr];
    [self initsaveReadArr];
    [self initsaveWriteArr];
    //设置代理
    [[RFIDBlutoothManager shareManager] setFatScaleBluetoothDelegate:self];
    
    [self initTopView];
    [self initScrollView];
    
    [self initScanView];
    [self initScanTwoView];
    [self initQrcodeView];
    [self initSettingView];
    
//    [self initEncryview];
//    [self initUserView];
    
    [self initReadView];
    [self initWriteView];
    [self initLockView];
    [self initDestoryView];
   
    
    
    [self initUpgradeView];
    
 //   [self initLockChooseView];
    
    [self initRigntBtn];
    
    self.chooseView=[ChooseView new];
    self.chooseView.frame=CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [[AppDelegate sharedDelegate].window addSubview:self.chooseView];
    [[AppDelegate sharedDelegate].window bringSubviewToFront:self.chooseView];
    self.chooseView.hidden=YES;
    
    
    self.rcodeArr=[[NSMutableArray alloc]init];
    
    
    [self getUpdateData];
    
}

-(void)initLockChooseView
{
    

    weakSelf(self);
    self.lockchooseVieww=[LockChooseeView new];
    [self.view addSubview:self.lockchooseVieww];
    [self.lockchooseVieww mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    self.lockchooseVieww.returnBlock = ^(NSString *str) {
        weakSelf.lockView.lockWordField.text=str;
    };
    [self.view bringSubviewToFront:self.lockchooseVieww];
    
    
}

-(void)initRigntBtn
{
    UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"..." forState:UIControlStateNormal];
    button.titleLabel.font=[UIFont boldSystemFontOfSize:28];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(rightbtnn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view).offset(-5);
        make.top.equalTo(self.view).offset(24);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(35);
    }];
    
    
    
}
-(void)rightbtnn
{
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *action1=[UIAlertAction actionWithTitle:@"Access to electricity" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
       //   [self initLockChooseView];
        [[RFIDBlutoothManager shareManager] getBatteryLevel];
    }];
    UIAlertAction *action2=[UIAlertAction actionWithTitle:@"Get version" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[RFIDBlutoothManager shareManager] getFirmwareVersion];//固件版本号
    //  [[RFIDBlutoothManager shareManager] getHardwareVersion];//硬件版本号
    }];
    UIAlertAction *action3=[UIAlertAction actionWithTitle:@"The module temperature" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[RFIDBlutoothManager shareManager] getServiceTemperature];//模块温度
    
    }];
    UIAlertAction *action4=[UIAlertAction actionWithTitle:@"升级" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {

        
        [[RFIDBlutoothManager shareManager] enterUpgradeMode];//进入升级模式
        sleep(2);
        [[RFIDBlutoothManager shareManager] enterUpgradeAcceptData];//进入升级接收数据
    }];
    UIAlertAction *action5=[UIAlertAction actionWithTitle:@"退出升级模式" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
         [[RFIDBlutoothManager shareManager] exitUpgradeMode];//退出升级模式
        
    }];
    UIAlertAction *action6=[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [alert addAction:action1];
    [alert addAction:action2];
    [alert addAction:action3];
    [alert addAction:action4];
    [alert addAction:action5];
    [alert addAction:action6];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void)initModelArr
{
        self.modelArr=[[NSMutableArray alloc]init];
        [self.modelArr addObject:@"China Standard1(840~845MHZ)"];
        [self.modelArr addObject:@"China Standard2(920~925MHZ)"];
        [self.modelArr addObject:@"Europe Standard(865~868MHZ)"];
        [self.modelArr addObject:@"America Standard(902~928MHZ)"];
        [self.modelArr addObject:@"Korea Standard(917~923MHZ)"];
        [self.modelArr addObject:@"Japan Standard(952~953MHZ)"];
}
-(void)initHopArr
{
    self.hopArr=[[NSMutableArray alloc]init];
    for (NSInteger i=0; i<50; i++) {
        [self.hopArr addObject:[NSString stringWithFormat:@"%.2lf",902.75+i*0.5]];
    }
}
-(void)initPutArr
{
    self.putArr=[[NSMutableArray alloc]init];
    for (NSInteger i=0; i<26; i++) {
        [self.putArr addObject:[NSString stringWithFormat:@"%d",5+i]];
    }
}
-(void)initencryModelArr
{
    self.encryModelArr=[[NSMutableArray alloc]init];
    [self.encryModelArr addObject:@"ECB"];
    [self.encryModelArr addObject:@"CBC"];
    [self.encryModelArr addObject:@"OFB"];
    [self.encryModelArr addObject:@"CFB"];
   
    
}
-(void)initsaveReadArr
{
    self.saveReadArr=[[NSMutableArray alloc]init];
    [self.saveReadArr addObject:@"RESERVED"];
    [self.saveReadArr addObject:@"EPC"];
    [self.saveReadArr addObject:@"TID"];
    [self.saveReadArr addObject:@"USER"];
}
-(void)initsaveWriteArr
{
    self.saveWriteArr=[[NSMutableArray alloc]init];
    [self.saveWriteArr addObject:@"RESERVED"];
    [self.saveWriteArr addObject:@"EPC"];
    [self.saveWriteArr addObject:@"TID"];
    [self.saveWriteArr addObject:@"USER"];
}
-(void)initTopView
{
    self.topView=[TopView new];
    [self.view addSubview:self.topView];
    [self.topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self.view);
        make.height.mas_equalTo(AdaptH(170));
    }];
    weakSelf(self);
    self.topView.searchBlock = ^{
        [[RFIDBlutoothManager shareManager] startBleScan];
        [weakSelf.searchAlert.dataSource removeAllObjects];
        [weakSelf.searchAlert.myTableView reloadData];
        [weakSelf.view addSubview:weakSelf.searchAlert];
    };
    self.topView.connectBlock = ^{
        if (weakSelf.isConnect) {
            [[RFIDBlutoothManager shareManager] cancelConnectBLE];
        }
        else
        {
            [[RFIDBlutoothManager shareManager] startBleScan];
            [weakSelf.searchAlert.dataSource removeAllObjects];
            [weakSelf.searchAlert.myTableView reloadData];
            [weakSelf.view addSubview:weakSelf.searchAlert];
        }
    };
}
-(void)initScrollView
{
    self.dataLinView=[[NSMutableArray alloc]init];
    
    _middleScrollView=[[UIScrollView alloc]init];
    _middleScrollView.delegate=self;
    _middleScrollView.backgroundColor = [UIColor clearColor];
    _middleScrollView.showsVerticalScrollIndicator = NO;
    _middleScrollView.showsHorizontalScrollIndicator = NO;
   // NSArray *aa=@[@"Inventory",@"Barcode Scan",@"Settings",@"加密",@"USER区加密",@"读数据",@"写数据",@"锁",@"销毁"];
    NSArray *aa=@[@"Inventory",@"New Inventory",@"Barcode Scan",@"Settings",@"Read",@"Write",@"Lock",@"Kill",@"upgrade"];
  //  NSArray *aa=@[@"盘点标签",@"二维码扫描",@"设置",@"读数据",@"写数据",@"锁",@"销毁",@"升级"];
    [self.view addSubview:_middleScrollView];
    [_middleScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.top.equalTo(self.topView.mas_bottom);
        make.height.mas_equalTo(AdaptH(60));
    }];
    _middleScrollView.contentSize=CGSizeMake(AdaptH(110)*aa.count, AdaptH(60));
    for (NSInteger i=0; i<aa.count; i++) {
        UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
        [_middleScrollView addSubview:button];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        button.tag=i;
        button.titleLabel.font=[UIFont systemFontOfSize:15];
        [button setTitle:aa[i] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(chooseBtn:) forControlEvents:UIControlEventTouchUpInside];
        button.frame=CGRectMake(i*AdaptH(110), 0, AdaptH(110), AdaptH(60));
        
        UIView *linView=[UIView new];
        [_middleScrollView addSubview:linView];
        linView.backgroundColor=RGB(230, 230, 230, 1);
        linView.frame=CGRectMake(i*AdaptH(110), AdaptH(10), 1, AdaptH(40));
        
        UIView *linView1=[UIView new];
        [_middleScrollView addSubview:linView1];
        linView1.tag=i;
        linView1.backgroundColor=RGB(200, 200, 200, 1);;
        linView1.frame=CGRectMake(i*AdaptH(110), AdaptH(57), AdaptH(110), 2);
        [self.dataLinView addObject:linView1];
        if (i==0) {
            linView1.hidden=NO;
        }
        else
        {
             linView1.hidden=YES;
        }
    }
}


-(void)initScanView
{
    self.scanView=[ScanView new];
    [self.view addSubview:self.scanView];
    [self.scanView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.scanView.dataSource=[[NSMutableArray alloc]init];
    self.scanView.tag=0;
    [self.dataBottomView addObject:self.scanView];
    [self.scanView.tableView reloadData];
    self.scanView.singleBlock = ^{
         [[RFIDBlutoothManager shareManager] singleSaveLabel];
    };
    self.scanView.beginBlock = ^{
        //开始扫描标签
        [[RFIDBlutoothManager shareManager] continuitySaveLabelWithCount:@"0"];
        [RFIDBlutoothManager shareManager].isgetLab=YES;
        usleep(20 * 1000);
        [[RFIDBlutoothManager shareManager] getLabMessage];
    };
    self.scanView.stopBlock = ^{
        [RFIDBlutoothManager shareManager].isgetLab=NO;
        //停止扫描标签
         [[RFIDBlutoothManager shareManager] StopcontinuitySaveLabel];
    };
    weakSelf(self);
    self.scanView.cleanBlock = ^{
        //清空数据
        [RFIDBlutoothManager shareManager].dataSource=[[NSMutableArray alloc]init];
        [RFIDBlutoothManager shareManager].countArr=[[NSMutableArray alloc]init];
        weakSelf.scanView.dataSource=[[NSMutableArray alloc]init];
        weakSelf.scanView.countArr=[[NSMutableArray alloc]init];
        [weakSelf.scanView.tableView reloadData];
        weakSelf.scanView.allCountLab.text=@"0";
        weakSelf.scanView.countLab.text=@"0";
    };
}

-(void)initScanTwoView
{
    weakSelf(self);
    self.scanTwoView=[ScanTwoView new];
    [self.view addSubview:self.scanTwoView];
    [self.scanTwoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.scanTwoView.dataSource=[[NSMutableArray alloc]init];
    self.scanTwoView.tag=1;
    self.scanTwoView.hidden=YES;
    [self.dataBottomView addObject:self.scanTwoView];
    [self.scanTwoView.tableView reloadData];
    
    self.scanTwoView.singleBlock = ^{
        [[RFIDBlutoothManager shareManager] singleSaveLabel];
    };
    
    [self.scanTwoView setEpcBlock:^{
        [[RFIDBlutoothManager shareManager] setEpcTidUserWithAddressStr:@"0" length:@"0" epcStr:@"0"];
    }];
    
    [self.scanTwoView setEpcTidBlock:^{
        [[RFIDBlutoothManager shareManager] setEpcTidUserWithAddressStr:@"0" length:@"0" epcStr:@"1"];
    }];
    
    [self.scanTwoView setEpcTidUserBlock:^{
        [[RFIDBlutoothManager shareManager] setEpcTidUserWithAddressStr:weakSelf.scanTwoView.userText.text length:weakSelf.scanTwoView.userLengthText.text epcStr:@"2"];
    }];
    
    self.scanTwoView.beginBlock = ^{
        //开始扫描标签
        [[RFIDBlutoothManager shareManager] continuitySaveLabelWithCount:@"0"];
        [RFIDBlutoothManager shareManager].isgetLab=YES;
        usleep(20 * 1000);
        [[RFIDBlutoothManager shareManager] getLabMessage];
    };
    self.scanTwoView.stopBlock = ^{
        [RFIDBlutoothManager shareManager].isgetLab=NO;
        //停止扫描标签
        [[RFIDBlutoothManager shareManager] StopcontinuitySaveLabel];
    };
   
    self.scanTwoView.cleanBlock = ^{
        //清空数据
        [RFIDBlutoothManager shareManager].dataSource=[[NSMutableArray alloc]init];
        [RFIDBlutoothManager shareManager].countArr=[[NSMutableArray alloc]init];
        weakSelf.scanTwoView.dataSource=[[NSMutableArray alloc]init];
        weakSelf.scanTwoView.countArr=[[NSMutableArray alloc]init];
        [weakSelf.scanTwoView.tableView reloadData];
        weakSelf.scanTwoView.allCountLab.text=@"0";
        weakSelf.scanTwoView.countLab.text=@"0";
    };
}

-(void)initQrcodeView
{
    self.codeView=[QRcodeView new];
    [self.view addSubview:self.codeView];
    [self.codeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.codeView.dataSource=[[NSMutableArray alloc]init];
    self.codeView.tag=2;
    [self.dataBottomView addObject:self.codeView];
    self.codeView.hidden=YES;
    [self.codeView.tableView reloadData];
    self.codeView.scanBlock = ^{
        [RFIDBlutoothManager shareManager].isCodeLab = YES;
         [[RFIDBlutoothManager shareManager] start2DScan];
    };
    
    weakSelf(self);
    self.codeView.cleanBlock = ^{
        //清空数据
        weakSelf.codeView.dataSource=[[NSMutableArray alloc]init];
        weakSelf.rcodeArr=[[NSMutableArray alloc]init];
        [weakSelf.codeView.tableView reloadData];
    };
}
-(void)initSettingView
{
    self.settingview=[SettingView new];
    [self.view addSubview:self.settingview];
    [self.settingview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.settingview.hidden=YES;
    self.settingview.tag=3;
    [self.dataBottomView addObject:self.settingview];
    [self.settingview.workBtn setTitle:self.modelArr[0] forState:UIControlStateNormal];
    [self.settingview.hopBtn setTitle:self.hopArr[0] forState:UIControlStateNormal];
     [self.settingview.putBtn setTitle:self.putArr[0] forState:UIControlStateNormal];
    weakSelf(self);
    self.settingview.workBlock = ^{
       
      //选工作模式
         [[AppDelegate sharedDelegate].window bringSubviewToFront:weakSelf.chooseView];
        weakSelf.chooseView.hidden=NO;
        weakSelf.chooseView.dataSource=[NSMutableArray arrayWithArray:weakSelf.modelArr];
        [weakSelf.chooseView.tableView reloadData];
        weakSelf.chooseView.removeBlock = ^{
            weakSelf.chooseView.hidden=YES;
         // [weakSelf.chooseView removeFromSuperview];
        };
        weakSelf.chooseView.returnBlock = ^(NSInteger index) {
         //  [weakSelf.chooseView removeFromSuperview];
            weakSelf.modelIndex=index;
            weakSelf.chooseView.hidden=YES;
            [weakSelf.settingview.workBtn setTitle:weakSelf.modelArr[index] forState:UIControlStateNormal];
        };
    };
    self.settingview.setpinBlock = ^{
      //设置频率
        [[RFIDBlutoothManager shareManager] setRegionWithsaveStr:@"1" regionStr:[NSString stringWithFormat:@"%ld",(long)weakSelf.modelIndex]];
        
    };
    self.settingview.readpinBlock = ^{
      //读取频率
         [[RFIDBlutoothManager shareManager] getRegion];
    };
    self.settingview.hopBlock = ^{
      //选择hop
         [[AppDelegate sharedDelegate].window bringSubviewToFront:weakSelf.chooseView];
        weakSelf.chooseView.hidden=NO;
        weakSelf.chooseView.dataSource=[NSMutableArray arrayWithArray:weakSelf.hopArr];
        [weakSelf.chooseView.tableView reloadData];
        weakSelf.chooseView.removeBlock = ^{
            weakSelf.chooseView.hidden=YES;
            // [weakSelf.chooseView removeFromSuperview];
        };
        weakSelf.chooseView.returnBlock = ^(NSInteger index) {
            //  [weakSelf.chooseView removeFromSuperview];
            weakSelf.hopIndex=index;
            weakSelf.chooseView.hidden=YES;
            [weakSelf.settingview.hopBtn setTitle:weakSelf.hopArr[index] forState:UIControlStateNormal];
        };
    };
    self.settingview.setdianBlock = ^{
      //设置频点
      //  [[RFIDBlutoothManager shareManager] getBatteryLevel];
       [[RFIDBlutoothManager shareManager] detailChancelSettingWithstring:weakSelf.hopArr[weakSelf.hopIndex]];
    };
    self.settingview.putBlock = ^{
      //输出功率
         [[AppDelegate sharedDelegate].window bringSubviewToFront:weakSelf.chooseView];
        weakSelf.chooseView.hidden=NO;
        weakSelf.chooseView.dataSource=[NSMutableArray arrayWithArray:weakSelf.putArr];
        [weakSelf.chooseView.tableView reloadData];
        weakSelf.chooseView.removeBlock = ^{
            weakSelf.chooseView.hidden=YES;
            // [weakSelf.chooseView removeFromSuperview];
        };
        weakSelf.chooseView.returnBlock = ^(NSInteger index) {
            //  [weakSelf.chooseView removeFromSuperview];
            weakSelf.putIndex=index;
            weakSelf.chooseView.hidden=YES;
            [weakSelf.settingview.putBtn setTitle:weakSelf.putArr[index] forState:UIControlStateNormal];
        };
    };
    self.settingview.setgongBlock = ^{
      //设置功率
         [[RFIDBlutoothManager shareManager] setLaunchPowerWithstatus:@"1" antenna:@"1" readStr:weakSelf.putArr[weakSelf.putIndex] writeStr:weakSelf.putArr[weakSelf.putIndex]];
    };
    self.settingview.readgongBlock = ^{
      //读取功率
        [[RFIDBlutoothManager shareManager] getLaunchPower];
    };
    self.settingview.usaBlock = ^{
      //选择USA
        [weakSelf.hopArr removeAllObjects];
        for (NSInteger i=0; i<50; i++) {
            [weakSelf.hopArr addObject:[NSString stringWithFormat:@"%.2lf",902.75+i*0.5]];
        }
        [weakSelf.settingview.hopBtn setTitle:weakSelf.hopArr[0] forState:UIControlStateNormal];
    };
    self.settingview.brazilBlock = ^{
      //选择brazil
        [weakSelf.hopArr removeAllObjects];
        for (NSInteger i=0; i<50; i++) {
            [weakSelf.hopArr addObject:[NSString stringWithFormat:@"%.1lf",902.5+i*0.5]];
        }
         [weakSelf.settingview.hopBtn setTitle:weakSelf.hopArr[0] forState:UIControlStateNormal];
         
    };
    self.settingview.otherBlock = ^{
      //选择其他
        [weakSelf.hopArr removeAllObjects];
        for (NSInteger i=0; i<50; i++) {
            [weakSelf.hopArr addObject:[NSString stringWithFormat:@"%.3lf",865.700+i*0.6]];
        }
         [weakSelf.settingview.hopBtn setTitle:weakSelf.hopArr[0] forState:UIControlStateNormal];
    };
    
    self.settingview.buzzerOpenBlock = ^{
      //开启蜂鸣器
         [[RFIDBlutoothManager shareManager] setOpenBuzzer];
    };
    self.settingview.buzzerCloseBlock = ^{
      //关闭蜂鸣器
         [[RFIDBlutoothManager shareManager] setCloseBuzzer];
    };
    
}
-(void)initEncryview
{
    weakSelf(self);
    self.encryView=[EncryptionView new];
     [self.view addSubview:self.encryView];
    [self.encryView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.encryView.hidden=YES;
    self.encryView.tag=4;
    [self.dataBottomView addObject:self.encryView];
    self.encryView.setmiBlock = ^{
      //设置密钥
        if (weakSelf.encryView.textField1.text.length!=32) {
            [BSprogreUtil showMBProgressWith:weakSelf.view andTipString:@"请输入正确的十六进制密钥" autoHide:YES];
            return ;
        }
        if (weakSelf.encryView.textField2.text.length!=32) {
            [BSprogreUtil showMBProgressWith:weakSelf.view andTipString:@"请输入正确的十六进制初始值" autoHide:YES];
            return ;
        }
        [RFIDBlutoothManager shareManager].typeStr=@"1";
        [[RFIDBlutoothManager shareManager] setSM4PassWordWithmodel:[NSString stringWithFormat:@"%ld",(long)weakSelf.encryModelIndex] password:weakSelf.encryView.textField1.text originPass:weakSelf.encryView.textField2.text];
        
    };
    self.encryView.getmiBlock = ^{
      //获取密钥
        [RFIDBlutoothManager shareManager].typeStr=@"2";
        [[RFIDBlutoothManager shareManager] getSM4PassWord];
    };
    self.encryView.modelBlock = ^{
      //选择model
        [[AppDelegate sharedDelegate].window bringSubviewToFront:weakSelf.chooseView];
        weakSelf.chooseView.hidden=NO;
        weakSelf.chooseView.dataSource=[NSMutableArray arrayWithArray:weakSelf.encryModelArr];
        [weakSelf.chooseView.tableView reloadData];
        weakSelf.chooseView.removeBlock = ^{
            weakSelf.chooseView.hidden=YES;
            // [weakSelf.chooseView removeFromSuperview];
        };
        weakSelf.chooseView.returnBlock = ^(NSInteger index) {
            //  [weakSelf.chooseView removeFromSuperview];
            weakSelf.encryModelIndex=index;
            weakSelf.chooseView.hidden=YES;
            [weakSelf.encryView.modeBtn setTitle:weakSelf.encryModelArr[index] forState:UIControlStateNormal];
        };
    };
    self.encryView.encryBlock = ^{
      //加密    //数据要是16字节的倍数
        [RFIDBlutoothManager shareManager].typeStr=@"3";
        [[RFIDBlutoothManager shareManager] encryptionPassWordwithmessage:weakSelf.encryView.textField3.text];
    };
    self.encryView.dencryBlock = ^{
      //解密
        [RFIDBlutoothManager shareManager].typeStr=@"4";
        [[RFIDBlutoothManager shareManager] decryptPassWordwithmessage:weakSelf.encryView.textField3.text];
    };
    
}
-(void)initUserView
{
    weakSelf(self);
    self.userrView=[USERView new];
    [self.view addSubview:self.userrView];
    [self.userrView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.userrView.hidden=YES;
    self.userrView.tag=5;
    [self.dataBottomView addObject:self.userrView];
    self.userrView.readBlock = ^{
      //读
        [RFIDBlutoothManager shareManager].typeStr=@"6";
         [[RFIDBlutoothManager shareManager] decryptUSERWithaddress:weakSelf.userrView.addressField.text lengthStr:weakSelf.userrView.lengthField.text];//USER解密
    };
    self.userrView.writeBlock = ^{
      //写
        [RFIDBlutoothManager shareManager].typeStr=@"5";
       [[RFIDBlutoothManager shareManager] encryptionUSERWithaddress:weakSelf.userrView.addressField.text lengthStr:weakSelf.userrView.lengthField.text dataStr:weakSelf.userrView.writeField.text];//USER加密
    };
}
-(void)initReadView
{
    weakSelf(self);
    self.readView=[ReadMessageView new];
    [self.view addSubview:self.readView];
    [self.readView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.readView.hidden=YES;
    self.readView.tag=6;
    [self.dataBottomView addObject:self.readView];
    [self.readView.saveBtn setTitle:self.saveReadArr[0] forState:UIControlStateNormal];
    self.readView.saveBlock = ^{
      //存储区
        [[AppDelegate sharedDelegate].window bringSubviewToFront:weakSelf.chooseView];
        weakSelf.chooseView.hidden=NO;
        weakSelf.chooseView.dataSource=[NSMutableArray arrayWithArray:weakSelf.saveReadArr];
        [weakSelf.chooseView.tableView reloadData];
        weakSelf.chooseView.removeBlock = ^{
            weakSelf.chooseView.hidden=YES;
            // [weakSelf.chooseView removeFromSuperview];
        };
        weakSelf.chooseView.returnBlock = ^(NSInteger index) {
            //  [weakSelf.chooseView removeFromSuperview];
            weakSelf.saveReadIndex=index;
            weakSelf.chooseView.hidden=YES;
            [weakSelf.readView.saveBtn setTitle:weakSelf.saveReadArr[index] forState:UIControlStateNormal];
            if (index==0) {
                weakSelf.readView.addressField1.text =@"0";
                weakSelf.readView.lengthField1.text=@"4";
            }
            else if (index==1)
            {
                weakSelf.readView.addressField1.text =@"2";
                weakSelf.readView.lengthField1.text=@"4";
            }
            else if (index==2)
            {
                weakSelf.readView.addressField1.text =@"0";
                weakSelf.readView.lengthField1.text=@"4";
            }
            else if (index==3)
            {
                weakSelf.readView.addressField1.text =@"0";
                weakSelf.readView.lengthField1.text=@"4";
            }
            
        };
    };
    self.readView.readMessageBlock = ^{
      //读取数据
        [[RFIDBlutoothManager shareManager] readLabelMessageWithPassword:weakSelf.readView.passWordField1.text MMBstr:weakSelf.readView.typeStr MSAstr:weakSelf.readView.addressField.text MDLstr:weakSelf.readView.lengthField.text MDdata:weakSelf.readView.dataField.text MBstr:[NSString stringWithFormat:@"%ld",(long)weakSelf.saveReadIndex] SAstr:weakSelf.readView.addressField1.text DLstr:weakSelf.readView.lengthField1.text isfilter:weakSelf.readView.isFilter];
        
    };
    
}
-(void)initWriteView
{
    weakSelf(self);
    self.writeView=[WriteMessageView new];
    [self.view addSubview:self.writeView];
    [self.writeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.writeView.hidden=YES;
    self.writeView.tag=7;
    [self.dataBottomView addObject:self.writeView];
    [self.writeView.saveBtn setTitle:self.saveWriteArr[0] forState:UIControlStateNormal];
    self.writeView.saveBlock = ^{
        //存储区
        [[AppDelegate sharedDelegate].window bringSubviewToFront:weakSelf.chooseView];
        weakSelf.chooseView.hidden=NO;
        weakSelf.chooseView.dataSource=[NSMutableArray arrayWithArray:weakSelf.saveWriteArr];
        [weakSelf.chooseView.tableView reloadData];
        weakSelf.chooseView.removeBlock = ^{
            weakSelf.chooseView.hidden=YES;
            // [weakSelf.chooseView removeFromSuperview];
        };
        weakSelf.chooseView.returnBlock = ^(NSInteger index) {
            //  [weakSelf.chooseView removeFromSuperview];
            weakSelf.saveWriteIndex=index;
            NSLog(@"index==%ld",(long)index);
            weakSelf.chooseView.hidden=YES;
            [weakSelf.writeView.saveBtn setTitle:weakSelf.saveWriteArr[index] forState:UIControlStateNormal];
            
            if (index==0) {
                weakSelf.writeView.addressField1.text =@"0";
                weakSelf.writeView.lengthField1.text=@"4";
            }
            else if (index==1)
            {
                weakSelf.writeView.addressField1.text =@"2";
                weakSelf.writeView.lengthField1.text=@"4";
            }
            else if (index==2)
            {
                weakSelf.writeView.addressField1.text =@"0";
                weakSelf.writeView.lengthField1.text=@"4";
            }
            else if (index==3)
            {
                weakSelf.writeView.addressField1.text =@"0";
                weakSelf.writeView.lengthField1.text=@"4";
            }
            
        };
    };
    self.writeView.writeMessageBlock = ^{
        //NSLog(@"saveWriteIndex====%@",[NSString stringWithFormat:@"%ld",(long)weakSelf.saveWriteIndex]);
        //写入数据
        [[RFIDBlutoothManager shareManager] writeLabelMessageWithPassword:weakSelf.writeView.passWordField1.text MMBstr:weakSelf.writeView.typeStr MSAstr:weakSelf.writeView.addressField.text MDLstr:weakSelf.writeView.lengthField.text MDdata:weakSelf.writeView.dataField.text MBstr:[NSString stringWithFormat:@"%ld",(long)weakSelf.saveWriteIndex] SAstr:weakSelf.writeView.addressField1.text DLstr:weakSelf.writeView.lengthField1.text writeData:weakSelf.writeView.dataField1.text isfilter:weakSelf.writeView.isFilter];
        
    };
}
-(void)initLockView
{
    weakSelf(self);
    self.lockView=[LockView new];
    [self.view addSubview:self.lockView];
    [self.lockView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.lockView.hidden=YES;
    self.lockView.tag=8;
    [self.dataBottomView addObject:self.lockView];
    self.lockView.lockBlock = ^{
      //锁
        [[RFIDBlutoothManager shareManager] lockLabelWithPassword:weakSelf.lockView.passWordField.text MMBstr:weakSelf.lockView.typeStr MSAstr:weakSelf.lockView.addressField.text MDLstr:weakSelf.lockView.lengthField.text MDdata:weakSelf.lockView.dataField.text ldStr:weakSelf.lockView.lockWordField.text isfilter:weakSelf.lockView.isFilter];
    };
    self.lockView.showlockBlock = ^{
        NSLog(@"lllll");
        [weakSelf initLockChooseView];
    };
}
-(void)initDestoryView
{
    weakSelf(self);
    self.destoryView=[DestroyView new];
    [self.view addSubview:self.destoryView];
    [self.destoryView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.destoryView.hidden=YES;
    self.destoryView.tag=9;
    [self.dataBottomView addObject:self.destoryView];
    self.destoryView.destoryBlock = ^{
      //销毁
        [[RFIDBlutoothManager shareManager] killLabelWithPassword:weakSelf.destoryView.passWordField.text MMBstr:weakSelf.destoryView.typeStr MSAstr:weakSelf.destoryView.addressField.text MDLstr:weakSelf.destoryView.lengthField.text MDdata:weakSelf.destoryView.dataField.text isfilter:weakSelf.destoryView.isFilter];
    };
}

-(void)initUpgradeView
{
    self.upgradeView=[UpgradeView new];
    [self.view addSubview:self.upgradeView];
    [self.upgradeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(_middleScrollView.mas_bottom);
    }];
    self.upgradeView.hidden=YES;
    self.upgradeView.tag=10;
    [self.dataBottomView addObject:self.upgradeView];
    self.upgradeView.upgradeBlock = ^{
        //进入升级模式
        [[RFIDBlutoothManager shareManager] enterUpgradeMode];
    };
}

-(void)chooseBtn:(UIButton *)button
{
    
    self.chooseIndex = button.tag;
    
    for (UIView *linView in self.dataLinView) {
        linView.hidden=YES;
        
    }
    UIView *linView=self.dataLinView[button.tag];
    linView.hidden=NO;
    
    for (UIView *view in self.dataBottomView) {
        view.hidden=YES;
    }
    UIView *view=self.dataBottomView[button.tag];
    view.hidden=NO;
    
    if (self.chooseIndex==0) {
        [RFIDBlutoothManager shareManager].isNewLab = NO;
    }
    else
    {
        [RFIDBlutoothManager shareManager].isNewLab = YES;
    }
}

#pragma mark - PeripheralAddDelegate

- (void)addPeripheralWithPeripheral:(BLEModel  *)peripheralModel
{
    
}

#pragma mark - BlutoothManagerDelegate
//#pragma 蓝牙连接失败
- (void)connectBluetoothFailWithMessage:(NSString *)msg
{
    
}

#pragma 蓝牙设备连接成功
- (void)fatscaleDidConnectSucess
{
    
}

#pragma mark - 成功接受到数据

-(void)receiveDataWithBLEmodel:(BLEModel *)model result:(NSString *)result {
    if ([result isEqualToString:@"0"]) {
        if (model!=nil) {
            [self.searchAlert.dataSource addObject:model];
            [self.searchAlert.myTableView reloadData];
        }
    } else {
        
        [self.searchAlert.cannelBtn setTitle:@"Scan" forState:UIControlStateNormal];
    }
    [self.searchAlert didSelectItem:^(BLEModel *model) {
        [[RFIDBlutoothManager shareManager] connectPeripheral:model.peripheral macAddress:model.addressStr];
    
    }];
}

//返回标签数据
-(void)receiveDataWithBLEDataSource:(NSMutableArray *)dataSource allCount:(NSInteger)allCount countArr:(NSMutableArray *)countArr dataSource1:(NSMutableArray *)dataSource1 countArr1:(NSMutableArray *)countArr1 dataSource2:(NSMutableArray *)dataSource2 countArr2:(NSMutableArray *)countArr2 {
    
    if (self.chooseIndex == 0) {
        self.scanView.dataSource=[NSMutableArray arrayWithArray:dataSource];
        self.scanView.countArr=[NSMutableArray arrayWithArray:countArr];
        
        NSInteger numcount=0;
        for (NSString *str in countArr) {
            numcount=numcount+str.integerValue;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.scanView.tableView reloadData];
            self.scanView.countLab.text=[NSString stringWithFormat:@"%lu",(unsigned long)dataSource.count];
            self.scanView.allCountLab.text=[NSString stringWithFormat:@"%ld",(long)numcount];
        });
    } else {
        self.scanTwoView.dataSource=[NSMutableArray arrayWithArray:dataSource];
        self.scanTwoView.countArr=[NSMutableArray arrayWithArray:countArr];
        self.scanTwoView.dataSource1=[NSMutableArray arrayWithArray:dataSource1];
        self.scanTwoView.countArr1=[NSMutableArray arrayWithArray:countArr1];
        self.scanTwoView.dataSource2=[NSMutableArray arrayWithArray:dataSource2];
        self.scanTwoView.countArr2=[NSMutableArray arrayWithArray:countArr2];
        
        NSInteger numcount=0;
        for (NSString *str in countArr) {
            numcount=numcount+str.integerValue;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.scanTwoView.tableView reloadData];
            self.scanTwoView.countLab.text=[NSString stringWithFormat:@"%lu",(unsigned long)dataSource.count];
            self.scanTwoView.allCountLab.text=[NSString stringWithFormat:@"%ld",(long)numcount];
        });
    }
}


//连接外设成功
-(void)connectPeripheralSuccess:(NSString *)nameStr
{
    NSLog(@"nameStr===%@",nameStr);
    self.topView.stateLab.text=[NSString stringWithFormat:@"Device:  %@-ready",nameStr];
    [self.topView.connectBtn setTitle:@"Disconnect" forState:UIControlStateNormal];
    self.isConnect=YES;
    [BSprogreUtil showMBProgressWith:self.view andTipString:@"Normal communication" autoHide:YES];
}
//断开外设
-(void)disConnectPeripheral
{
    self.topView.stateLab.text=@"Device:  Not Connected";
    [self.topView.connectBtn setTitle:@"connect" forState:UIControlStateNormal];
    self.isConnect=NO;
    [BSprogreUtil showMBProgressWith:self.view andTipString:@"Bluetooth is disconnected" autoHide:YES];
}

//发送指令成功返回数据
-(void)receiveMessageWithtype:(NSString *)typeStr dataStr:(NSString *)dataStr {
    if ([typeStr isEqualToString:@"2d"]) {
        //设置频率
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    }
    else if ([typeStr isEqualToString:@"2f"])
    {
        //读取频率
        [self.settingview.workBtn setTitle:self.modelArr[dataStr.integerValue] forState:UIControlStateNormal];
        [BSprogreUtil showMBProgressWith:self.view andTipString:@"Read frequency successful" autoHide:YES];
        
    }
    else if ([typeStr isEqualToString:@"15"])
    {
        //设置频点
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    }
    else if ([typeStr isEqualToString:@"11"])
    {
        //设置功率
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    }
    else if ([typeStr isEqualToString:@"13"])
    {
        //读取功率
        [self.settingview.putBtn setTitle:dataStr forState:UIControlStateNormal];
        [BSprogreUtil showMBProgressWith:self.view andTipString:@"Read power successfully" autoHide:YES];
    } else if ([typeStr isEqualToString:@"e31"]) {
        //设置密钥
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    } else if ([typeStr isEqualToString:@"e32"]) {
        //获取密钥
        self.encryView.textField1.text=[dataStr substringWithRange:NSMakeRange(0, 32)];
        self.encryView.textField2.text=[dataStr substringWithRange:NSMakeRange(32, 32)];
        [BSprogreUtil showMBProgressWith:self.view andTipString:@"获取密钥成功" autoHide:YES];
    }else if ([typeStr isEqualToString:@"e33"]) {
        //SM4加密
       [BSprogreUtil showMBProgressWith:self.view andTipString:@"加密成功" autoHide:YES];
       self.encryView.textField3.text=dataStr;
        
    } else if ([typeStr isEqualToString:@"e34"]) {
        //SM4解密
        [BSprogreUtil showMBProgressWith:self.view andTipString:@"解密成功" autoHide:YES];
        self.encryView.textField4.text=dataStr;
    } else if ([typeStr isEqualToString:@"e35"]){
        //USER加密
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    } else if ([typeStr isEqualToString:@"e36"]) {
        //USER解密
        [BSprogreUtil showMBProgressWith:self.view andTipString:@"读成功" autoHide:YES];
        self.userrView.readField.text=dataStr;
    } else if ([typeStr isEqualToString:@"85"]) {
        //读数据
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
        self.readView.dataField1.text=dataStr;
    } else if ([typeStr isEqualToString:@"87"]) {
        //写数据  
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    } else if ([typeStr isEqualToString:@"89"]) {
        //锁标签
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    }else if ([typeStr isEqualToString:@"8b"]) {
        //销毁
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    } else if ([typeStr isEqualToString:@"e5"]) {
        //电池电量
        NSString *str=[NSString stringWithFormat:@"Battery：%@%@",dataStr,@"%"];
        [BSprogreUtil showMBProgressWith:self.view andTipString:str autoHide:YES];
    } else if ([typeStr isEqualToString:@"e55"]) {
        //扫描得到的二维码数据
        [self.rcodeArr addObject:dataStr];
        self.codeView.dataSource=[NSMutableArray arrayWithArray:self.rcodeArr];
        [self.codeView.tableView reloadData];
    } else if ([typeStr isEqualToString:@"35"]) {
        //设备温度
        NSString *str=[NSString stringWithFormat:@"Temperature：%@%@",dataStr,@"c"];
        [BSprogreUtil showMBProgressWith:self.view andTipString:str autoHide:YES];
    } else if ([typeStr isEqualToString:@"03"]) {
        //获取固件版本号
        NSString *str=[NSString stringWithFormat:@"Version：%@",dataStr];
        [BSprogreUtil showMBProgressWith:self.view andTipString:str autoHide:YES];
    } else if ([typeStr isEqualToString:@"c9"]) {
        //获取升级固件版本号
        NSString *str=[NSString stringWithFormat:@"升级后版本号：%@",dataStr];
        [BSprogreUtil showMBProgressWith:self.view andTipString:str autoHide:YES];
    } else if ([typeStr isEqualToString:@"01"]) {
        //获取硬件版本号
        NSString *str=[NSString stringWithFormat:@"Version：%@",dataStr];
        [BSprogreUtil showMBProgressWith:self.view andTipString:str autoHide:YES];
    }else if ([typeStr isEqualToString:@"69"]){
        //软件复位
        if ([dataStr isEqualToString:@"软件复位成功"]) {
            
        }
         [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    } else if ([typeStr isEqualToString:@"e50"]) {
        //开启蜂鸣器
       
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    } else if ([typeStr isEqualToString:@"e51"]) {
        //关闭蜂鸣器
      
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    } else if ([typeStr isEqualToString:@"71"]) {
        //设置标签读取格式
        [BSprogreUtil showMBProgressWith:self.view andTipString:dataStr autoHide:YES];
    } else if ([typeStr isEqualToString:@"73"]) {
        [BSprogreUtil showMBProgressWith:self.view andTipString:@"Achieving Success" autoHide:YES];
        //获取标签读取格式
        NSArray *aa=[dataStr componentsSeparatedByString:@" "];
        if (aa.count == 3) {
            [self.scanTwoView chooseSelectWith:aa[0]];
            self.scanTwoView.userText.text = aa[1];
            self.scanTwoView.userLengthText.text = aa[2];
        }
    } else if ([typeStr isEqualToString:@"c1"]) {
        //进入升级模式
        if ([dataStr isEqualToString:@"01"]) {
           // [BSprogreUtil showMBProgressWith:self.view andTipString:@"进入升级模式成功" autoHide:YES];
        }
    } else if ([typeStr isEqualToString:@"c3"]) {
        //进入升级接收数据模式
        if ([dataStr isEqualToString:@"01"]) {
            [BSprogreUtil showMBProgressWith:self.view andTipString:@"进入升级接收数据成功" autoHide:YES];
            //
            
             [[RFIDBlutoothManager shareManager] enterUpgradeSendtDataWith:_updateArr[0]];//发送升级数据
            
        }
    } else if ([typeStr isEqualToString:@"c5"]) {
        //进入升级发送数据
        if ([dataStr isEqualToString:@"01"]) {
            self.updateIndex++;
            if (self.updateIndex == self.updateArr.count) {
                //发送完成
                [[RFIDBlutoothManager shareManager] exitUpgradeMode];//退出升级模式
            } else {
                [[RFIDBlutoothManager shareManager] enterUpgradeSendtDataWith:_updateArr[self.updateIndex]];//发送升级数据
            }
        } else {
             [[RFIDBlutoothManager shareManager] enterUpgradeSendtDataWith:_updateArr[self.updateIndex]];//发送升级数据
        }
    } else if ([typeStr isEqualToString:@"c7"]) {
        //退出升级模式
        if ([dataStr isEqualToString:@"01"]) {
            [BSprogreUtil showMBProgressWith:self.view andTipString:@"升级成功" autoHide:YES];
            NSLog(@"升级成功");
        }
    } else if ([typeStr isEqualToString:@"e6"]) {
        //按硬件scan按钮之后的返回
        if (self.chooseIndex == 0) {
            //当前界面选中标签界面  开始进行标签扫描或者停止操作
            if ([RFIDBlutoothManager shareManager].isgetLab) {
                [self.scanView.beginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                [self.scanView.stopBtn setTitleColor:RGB(133, 133, 133, 1) forState:UIControlStateNormal];
                [self.scanView.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                //停止扫描
                [RFIDBlutoothManager shareManager].isgetLab=NO;
                //停止扫描标签
                [[RFIDBlutoothManager shareManager] StopcontinuitySaveLabel];
            } else {
                [self.scanView.beginBtn setTitleColor:RGB(133, 133, 133, 1) forState:UIControlStateNormal];
                [self.scanView.stopBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                [self.scanView.cleanBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                //开始扫描标签
                [[RFIDBlutoothManager shareManager] continuitySaveLabelWithCount:@"10000"];
                [RFIDBlutoothManager shareManager].isgetLab=YES;
                usleep(20 * 1000);
                [[RFIDBlutoothManager shareManager] getLabMessage];
            }
        } else {
            //当前界面选中的是二维码扫描  开始进行二维码扫描
            [[RFIDBlutoothManager shareManager] start2DScan];
        }
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
