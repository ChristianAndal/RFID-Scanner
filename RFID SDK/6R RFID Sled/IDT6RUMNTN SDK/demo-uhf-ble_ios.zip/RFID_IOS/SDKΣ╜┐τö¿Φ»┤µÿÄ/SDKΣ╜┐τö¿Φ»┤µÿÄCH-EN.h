##一.UHF SDK概述:
UHF SDK Intro:

&emsp;&emsp;开发者集成Bt ios SDK到其应用里,调用SDK的api,可蓝牙连接UHF设备,与UHF设备进行正常通信。通过调用SDK提供的指令接口,向UHF设备发出命令,UHF接收到指令后执行相应的动作,通过蓝牙BLE协议发出相应的数据信息.开发者应用根据SDK提供的注册广播接受者,来监听获得UHF所发出的信息.
Developer integrated Bt ios SDK into application to call api, connect UHF device through BT and communicate with UHF device. To call interface in SDK and send command to UHF device, then it will execute according commands. Developer could use broadcast to monitor UHF infor.

##二.UHF SDK压缩包说明:
UHF SDK pack Intro

#####&emsp;&emsp;提供给的SDK压缩包包含以下几部分:
SDK pack contains:

- UHF设备的sdk
- UHF device SDK
- sdk的使用说明
-SDK instruction
- demo文件夹
-demo


##三.快速使用UHF蓝牙 ios demo
UHF BT ios demo

###1.直接在xcode上运行Demo
Operate Demo in xcode.

###2.进入demo的主界面
Enter demo interface

###3.点击Connect按钮,弹出扫描蓝牙设备的对话框;
Click "Connect" button to pop up BT device searching dialog.

###&emsp;扫描5s自动结束扫描,可点击Scan按钮重新扫描;
Stop scanning after 5s auto scan, click SCAN button to restart scanning


###&emsp;此演示,选择经络仪设备的名字进行连接;

 


###设备接收到蓝牙设备的信息,都显示界面的中间信息栏里;
BT information will display in information bar

按钮的功能指令及信息栏介绍详情,请参考《BtDemo(电阻版)的App使用说明》;
Function of button and information bar introduction could be checked in App operating manual of BtDemo

###7.点击Disconnect按钮,断开蓝牙设备"myEdoctor"的连接;
Click Disconnect button to disconnect BT connection


##五.UHF蓝牙SDK集成指南:
BT device SDK instruction:

###把RFID_IOS_SDK这个文件夹集成进去你新建的项目中，把#import "RFIDBlutoothManager.h" ，#import "BLEModel.h"这两个声明加入你所要操作的控制器中即可
Integrate RFID_IOS_SDK folder into new project, and add #import "RFIDBlutoothManager.h" ，#import "BLEModel.h" statements into controller

RFIDBlutoothManager中写有单例，可参照Demo直接调用里面的api进行开发操作
RFIDBluetoothManager has example and developer could call api according to demo to operate

//注明：Note
//需要实现代理 Need to realize proxy
//设置代理 Setup proxy
[[RFIDBlutoothManager shareManager] setFatScaleBluetoothDelegate:self];

//需要实现以下代理协议方法 Need to realize proxy method as follows.
//蓝牙列表数据 BT list data
//此函数回调返回的是搜索到的附近的蓝牙设备的名字，mac地址，信号轻度，以及外设。返回的result是0的时候说明还正在搜索附近设备，返回为1的时候说明已经搜索完毕 This function could be used to search BT devices, signal strengh, MAC address. If feedback result is 0, then  there is not BT device, feeback is 1, then it means searching has comleted.
- (void)receiveDataWithBLEmodel:(BLEModel *)model result:(NSString *)result;

//返回标签数据 Feedback tag data 
-(void)receiveDataWithBLEDataSource:(NSMutableArray *)dataSource allCount:(NSInteger)allCount countArr:(NSMutableArray *)countArr

//发送指令成功返回数据 Feedback data after successfully sending command
-(void)receiveMessageWithtype:(NSString *)typeStr dataStr:(NSString *)dataStr

//连接外设成功 External device connection succeed
- (void)connectPeripheralSuccess:(NSString *)nameStr;

//断开外设 Disconnect external device
-(void)disConnectPeripheral;





- (void)startBleScan;                // 开启蓝牙扫描 Switch on BT scanning
- (void)cancelConnectBLE;             //断开连接 Disconnect connection
- (void)closeBleAndDisconnect;       // 停止蓝牙扫描&断开 Stop BT scanning & disconnect

 
-(void)getFirmwareVersion2;//获取固件版本号 Collect firmware version
-(void)getBatteryLevel;//获取电池电量 Collect battery infor
-(void)getServiceTemperature;//获取设备当前温度 Collect current temp. of device
-(void)start2DScan;//开启2D扫描 Switch on 2D scanning
-(void)getHardwareVersion;//获取硬件版本号 Collect hardware version
-(void)getFirmwareVersion;//获取固件版本号 Collect firmware version
-(void)getServiceID;//获取设备ID Collect device ID
-(void)softwareReset;//软件复位 Reset


-(void)setLaunchPowerWithstatus:(NSString *)status antenna:(NSString *)antenna readStr:(NSString *)readStr writeStr:(NSString *)writeStr;//设置发射功率 Device output power
-(void)getLaunchPower;//获取当前发射功率 Collect current output power
-(void)detailChancelSettingWithstring:(NSString *)str;//跳频设置 Frequecy hopping setup
-(void)getdetailChancelStatus;//获取当前跳频设置状态 Collect current frequency hopping setup status


-(void)setRegionWithsaveStr:(NSString *)saveStr regionStr:(NSString *)regionStr;//区域设置 region setup
-(void)getRegion;//获取区域设置 Collect region setup

-(void)continuitySaveLabelWithCount:(NSString *)count;//连续盘存标签 Continuous counting tags
-(void)StopcontinuitySaveLabel;//停止连续盘存标签 Stop continous counting tags

//password:4个字节的访问密码.  MMBstr:掩码的数据区(0x00为Reserve 0x01为EPC，0x02表示TID，0x03表示USR). MSAstr:为掩码的地址。 MDLstr:为掩码的长度。 Mdata:为掩码数据。 MBstr:为要写的数据区(0x00为Reserve 0x01为EPC，0x02表示TID，0x03表示USR)  SAstr :为要写数据区的地址。 DLstr :为要写的数据长度(字为单位)。 isfilter表示是否过滤
//password: 4 bytes access password. MMBstr: (0x00 is Reserve 0x01 is EPC，0x02 is TID，0x03 is USR). MSAstr: mask address. MDLstr: mask length. Mdata: mask data. MBstr: writeData zone (0x00 is Reserve 0x01 is EPC，0x02 is TID，0x03 is USR) SAstr : WriteData zone address. DLstr : WriteData length. 
-(void)readLabelMessageWithPassword:(NSString *)password MMBstr:(NSString *)MMBstr MSAstr:(NSString *)MSAstr MDLstr:(NSString *)MDLstr MDdata:(NSString *)MDdata MBstr:(NSString *)MBstr SAstr:(NSString *)SAstr DLstr:(NSString *)DLstr isfilter:(BOOL)isfilter;//读标签数据区   成功

//password:4个字节的访问密码.  MMBstr:掩码的数据区(0x00为Reserve 0x01为EPC，0x02表示TID，0x03表示USR). MSAstr:为掩码的地址。 MDLstr:为掩码的长度。 Mdata:为掩码数据。 MBstr:为要写的数据区(0x00为Reserve 0x01为EPC，0x02表示TID，0x03表示USR)  SAstr :为要写数据区的地址。 DLstr :为要写的数据长度(字为单位)。 writeData :为写入的数据，高位在前。 isfilter表示是否过滤
//password: 4 bytes access password. MMBstr: (0x00 is Reserve 0x01 is EPC，0x02 is TID，0x03 is USR). MSAstr: mask address. MDLstr: mask length. Mdata: mask data. MBstr: writeData zone (0x00 is Reserve 0x01 is EPC，0x02 is TID，0x03 is USR) SAstr : WriteData zone address. DLstr : WriteData length. 
-(void)writeLabelMessageWithPassword:(NSString *)password MMBstr:(NSString *)MMBstr MSAstr:(NSString *)MSAstr MDLstr:(NSString *)MDLstr MDdata:(NSString *)MDdata MBstr:(NSString *)MBstr SAstr:(NSString *)SAstr DLstr:(NSString *)DLstr writeData:(NSString *)writeData isfilter:(BOOL)isfilter;//写标签数据区   成功

//AP 为标签的 AccPwd 值;MMB 为启动过滤操作的 bank 号，0x01 表 示 EPC，0x02 表示 TID，0x03 表示 USR，其他值为非法值;MSA 为启动过滤 操作的起始地址，单位为 bit;MDL为启动过滤操作的过滤数据长度，单位为 bit，0x00 表示无过滤;MData 为启动过滤时的数据，单位为字节，若 MDL 不足整数 倍字节，不足位低位补 0;LD 共 3 个字节 24bit，其中，高 4bit 无效，第 0~9bit(共10bit)为 Action 位，第 10~19bit(共 10bit)为 mask 位 isfilter表示是否过滤
//AP is AccPwd value of tag; MMB is bank number of filter, 0x00 is Reserve 0x01 is EPC，0x02 is TID，0x03 is USR, other values are invalid; MSA is used to switch on filter initial address, unit is bit. 0x00 means filter; MData is the data when switching on filter, unit is byte. 
-(void)lockLabelWithPassword:(NSString *)password MMBstr:(NSString *)MMBstr MSAstr:(NSString *)MSAstr MDLstr:(NSString *)MDLstr MDdata:(NSString *)MDdata ldStr:(NSString *)ldStr isfilter:(BOOL)isfilter;//Lock标签

//KP 为标签的 KillPwd 值;MMB 为启动过滤操作的 bank 号，0x01 表 示 EPC，0x02 表示 TID，0x03 表示 USR，其他值为非法值;MSA 为启动过滤 操作的起始地址，单位为 bit;MDL为启动过滤操作的过滤数据长度，单位为 bit， 0x00 表示无过滤;MData 为启动过滤时的数据，单位为字节，若 MDL 不足整数 倍字节，不足位低位补 0;当标签的 KillPwd 区的值为 0x00000000 时，标签会忽 略 kill 命令，kill 命令不会成功 isfilter表示是否过滤
//KP is KillPwd value; MMB is bank number of filter, 0x01 is EPC, 0x02 is TID，0x03 is USR, other values are invalid; MSA is used to switch on filter initial address, unit is bit; MDL is filter data length to switch on filter, unit is bit. 0x00 means no filter; MData is the data when switching on filter, unit is byte.
-(void)killLabelWithPassword:(NSString *)password MMBstr:(NSString *)MMBstr MSAstr:(NSString *)MSAstr MDLstr:(NSString *)MDLstr MDdata:(NSString *)MDdata isfilter:(BOOL)isfilter;//kill标签

-(void)getLabMessage;//获取标签数据 可以 collect tag data 


//注明：有相关疑问的可详细参照Demo中的代码 Check demo codes for all information.



